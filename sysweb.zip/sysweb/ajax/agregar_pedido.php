<?php
require_once "../../../connection.php";
session_start();
if (!isset($_SESSION['carrito_compras'])) {
    $_SESSION['carrito_compras'] = array();
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $precio_compra = $_POST['precio_compra'];
    $cantidad = $_POST['cantidad'];
    $query = pg_query($conn, "SELECT p_descrip FROM producto WHERE cod_producto = $id");
    $producto = pg_fetch_assoc($query);
    
    if ($producto) {
        $_SESSION['carrito_compras'][$id] = array(
            'id' => $id,
            'nombre' => $producto['p_descrip'],
            'precio' => $precio_compra,
            'cantidad' => $cantidad,
            'subtotal' => $precio_compra * $cantidad
        );
        
        echo "exito|Producto agregado correctamente";
    } else {
        echo "error|Producto no encontrado";
    }
    exit();
}
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    if (isset($_SESSION['carrito_compras'][$id])) {
        unset($_SESSION['carrito_compras'][$id]);
        echo "eliminado|Producto eliminado correctamente";
    } else {
        echo "error|Producto no encontrado en el carrito";
    }
    exit();
}
?>