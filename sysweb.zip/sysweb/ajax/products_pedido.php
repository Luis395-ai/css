<?php
error_log("products_pedido.php ejecutado");
require_once "../config/database.php"; 
$action = (isset($_REQUEST['action']) && $_REQUEST['action'] != NULL) ? $_REQUEST['action'] : '';

if($action == 'ajax') {
    
    $x = (isset($_REQUEST['x']) && $_REQUEST['x'] != NULL) ? $_REQUEST['x'] : '';
    $columns = array('cod_producto', 'p_descrip', 'precio');
    $table = 'producto';
    $sWhere = "";
    
    if($x != "") {
        $sWhere = "WHERE (";
        for($i = 0; $i < count($columns); $i++) {
            $sWhere .= $columns[$i] . " ILIKE '%" . $x . "%' OR ";
        }
        $sWhere = substr_replace($sWhere, "", -3);
        $sWhere .= ')';
    }
    $page = (isset($_REQUEST['page']) && !empty($_REQUEST['page'])) ? $_REQUEST['page'] : 1;
    $per_page = 10;
    $adjacents = 4;
    $offset = ($page - 1) * $per_page;

    $count_query = pg_query($conn, "SELECT COUNT(*) AS numrows FROM $table $sWhere");
    if($count_query) {
        $row = pg_fetch_array($count_query);
        $numrows = $row['numrows'];
        $total_pages = ceil($numrows / $per_page);
        $reload = 'ajax/products_pedido.php';
        
        $query = pg_query($conn, "SELECT * FROM $table $sWhere ORDER BY p_descrip LIMIT $per_page OFFSET $offset");

        if($numrows > 0) { 
            echo '<div class="table-responsive">';
            echo '<table class="table table-bordered table-striped table-hover">';
            echo '<tr class="warning">';
            echo '<th>Código</th>';
            echo '<th>Producto</th>';
            echo '<th><span class="pull-right">Cantidad</span></th>';
            echo '<th><span class="pull-right">Precio</span></th>';
            echo '<th style="width: 36px;">Seleccionar</th>';
            echo '</tr>';
            
            while($row = pg_fetch_array($query)) {
                $id_producto = $row['cod_producto'];
                $producto_nombre = $row['p_descrip'];
                $precio_compra = $row['precio'];
                
                echo '<tr>';
                echo '<td>' . $id_producto . '</td>';
                echo '<td>' . $producto_nombre . '</td>';
                echo '<td class="col-xs-1">';
                echo '<div class="pull-right">';
                echo '<input type="text" class="form-control" style="text-align:right" id="cantidad_' . $id_producto . '" value="1" size="3">';
                echo '</div>';
                echo '</td>';
                echo '<td class="col-xs-2">';
                echo '<div class="pull-right">';
                echo '<input type="text" class="form-control" style="text-align:right" id="precio_compra_' . $id_producto . '" value="' . number_format($precio_compra, 2) . '" size="8">';
                echo '</div>';
                echo '</td>';
                echo '<td>';
                echo '<span class="pull-right">';
                echo '<a href="#" onclick="agregarProducto(' . $id_producto . ')" class="btn btn-default"><i class="glyphicon glyphicon-plus"></i></a>';
                echo '</span>';
                echo '</td>';
                echo '</tr>';
            }
            echo '</table>';
            echo '</div>';
            if($total_pages > 1) {
                echo '<div class="pull-right">';
                echo '<ul class="pagination pagination-sm">';
                if($page > 1) {
                    echo '<li><a href="javascript:void(0);" onclick="load(' . ($page - 1) . ')">&laquo; Anterior</a></li>';
                }
                for($i = 1; $i <= $total_pages; $i++) {
                    if($i == $page) {
                        echo '<li class="active"><span>' . $i . '</span></li>';
                    } else {
                        echo '<li><a href="javascript:void(0);" onclick="load(' . $i . ')">' . $i . '</a></li>';
                    }
                }
                if($page < $total_pages) {
                    echo '<li><a href="javascript:void(0);" onclick="load(' . ($page + 1) . ')">Siguiente &raquo;</a></li>';
                }
                
                echo '</ul>';
                echo '</div>';
            }
        } else {
            echo '<div class="alert alert-warning">';
            echo '<strong>No se encontraron productos.</strong>';
            echo '</div>';
        }
    } else {
        echo '<div class="alert alert-danger">';
        echo '<strong>Error en la consulta: ' . pg_last_error($conn) . '</strong>';
        echo '</div>';
    }
} else {
    echo '<div class="alert alert-info">';
    echo '<strong>Acción no válida.</strong>';
    echo '</div>';
}
?>