<?php 
require "config/database.php";
if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
    echo "<meta http-equiv='refresh' content='0; url=index.php?alert=1'>";
} else {

    if (isset($_GET['module']) && $_GET['module'] == 'start') {
        include "modules/start/view.php";
    }elseif ($_GET['module']== 'password') {
        include "modules/password/view.php";
    }elseif ($_GET['module']== 'user') {
        include "modules/user/form.php";
    }
}
?>
