<?php
require_once 'config/database.php';

echo "<h3>DEBUG DEL LOGIN</h3>";

// Simular el login
$username = 'PEDRO';
$password = '123456';

echo "Username: " . $username . "<br>";
echo "Password: " . $password . "<br>";
echo "MD5 del password: " . md5($password) . "<br><br>";

$query = "SELECT username, password FROM usuarios WHERE username = $1";
$result = pg_query_params($conn, $query, [$username]);

if ($result) {
    $user = pg_fetch_assoc($result);
    echo "Usuario en BD: " . ($user['username'] ?? 'NO ENCONTRADO') . "<br>";
    echo "Password en BD: " . ($user['password'] ?? 'NO ENCONTRADO') . "<br>";
    echo "Coinciden: " . (md5($password) === ($user['password'] ?? '') ? 'SÍ' : 'NO') . "<br>";
    
    if ($user && md5($password) === $user['password']) {
        echo "<h4 style='color:green;'>✓ LOGIN EXITOSO</h4>";
    } else {
        echo "<h4 style='color:red;'>✗ LOGIN FALLIDO</h4>";
    }
} else {
    echo "Error en la consulta";
}
?>