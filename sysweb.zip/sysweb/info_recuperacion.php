<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Información de Recuperación - Desarrollo</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Información para Desarrollo - PostgreSQL</h2>
        <?php if (isset($_SESSION['enlace_recuperacion'])): ?>
            <div class="alert alert-info">
                <h4>En WampServer con PostgreSQL:</h4>
                <p><strong>Email del usuario:</strong> <?php echo $_SESSION['email_usuario']; ?></p>
                <p><strong>Enlace de recuperación (haz clic):</strong></p>
                <a href="<?php echo $_SESSION['enlace_recuperacion']; ?>" class="btn btn-primary btn-lg">
                    Restablecer Contraseña
                </a>
                <p class="mt-3"><small>O copia esta URL: <?php echo $_SESSION['enlace_recuperacion']; ?></small></p>
            </div>
            <?php 
            unset($_SESSION['enlace_recuperacion']);
            unset($_SESSION['email_usuario']);
            ?>
        <?php else: ?>
            <div class="alert alert-warning">
                No hay información de recuperación disponible.
            </div>
        <?php endif; ?>
        <a href="recuperar.php" class="btn btn-secondary">Volver al formulario</a>
        <a href="index.php" class="btn btn-secondary">Ir al Login</a>
    </div>
</body>
</html>