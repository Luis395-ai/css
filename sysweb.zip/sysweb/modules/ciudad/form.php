<?php
if (isset($_GET['form']) && $_GET['form'] === 'add') { 
  
  $query_id = pg_query($conn, "SELECT MAX(cod_compra) as id FROM compras")
              or die('Error: '.pg_last_error($conn));
  $data_id = pg_fetch_assoc($query_id);
  $codigo = ($data_id && $data_id['id'] != null) ? (int)$data_id['id'] + 1 : 1;
  
  $fecha_actual = date('Y-m-d');
  $hora_actual = date('H:i:s');
?>
  <section class="content-header">
    <h1><i class="fa fa-edit icon-title"></i> Agregar Compras</h1>
    <ol class="breadcrumb">
      <li><a href="?module=start"><i class="fa fa-home"></i> Inicio</a></li>
      <li><a href="?module=compras">Compras</a></li>
      <li class="active">Agregar</li>
    </ol>
  </section>

  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <form role="form" class="form-horizontal" 
                action="modules/compras/proses.php?act=insert" 
                method="POST">
            <div class="box-body">
              <div class="form-group">
                <label class="col-sm-2 control-label">Código</label>
                <div class="col-sm-2">
                  <input type="text" class="form-control" 
                         name="cod_compra" 
                         value="<?php echo htmlspecialchars($codigo); ?>" readonly>
                </div>
                
                <label class="col-sm-1 control-label">Fecha</label>
                <div class="col-sm-2">
                  <input type="date" class="form-control" 
                         name="fecha_compra" 
                         value="<?php echo $fecha_actual; ?>" required>
                </div>
                
                <label class="col-sm-1 control-label">Hora</label>
                <div class="col-sm-2">
                  <input type="time" class="form-control" 
                         name="hora_compra" 
                         value="<?php echo $hora_actual; ?>" required>
                </div>
              </div>
              
              <div class="form-group">
                <label class="col-sm-2 control-label">Proveedor</label>
                <div class="col-sm-4">
                  <select name="cod_proveedor" class="form-control" required>
                    <option value="">--Seleccionar Proveedor--</option>
                    <?php
                    $query = pg_query($conn, "SELECT cod_proveedor, nom_proveedor FROM proveedor ORDER BY cod_proveedor")
                             or die("Error: ".pg_last_error($conn));
                    while($data = pg_fetch_assoc($query)){
                      echo "<option value='".$data['cod_proveedor']."'";
                      if(isset($_POST['cod_proveedor']) && $_POST['cod_proveedor'] == $data['cod_proveedor']) {
                        echo " SELECTED";
                      }
                      echo ">";
                      echo $data['cod_proveedor']." - ".$data['nom_proveedor'];
                      echo "</option>";
                    }
                    ?>
                  </select>
                </div>
                
                <label class="col-sm-2 control-label">Depósito</label>
                <div class="col-sm-4">
                  <select name="cod_deposito" class="form-control" required>
                    <option value="">--Seleccionar Depósito--</option>
                    <?php
                    $query = pg_query($conn, "SELECT cod_deposito, descripcion FROM deposito ORDER BY cod_deposito")
                             or die("Error: ".pg_last_error($conn));
                    while($data = pg_fetch_assoc($query)){
                      echo "<option value='".$data['cod_deposito']."'";
                      if(isset($_POST['cod_deposito']) && $_POST['cod_deposito'] == $data['cod_deposito']) {
                        echo " SELECTED";
                      }
                      echo ">";
                      echo $data['cod_deposito']." - ".$data['descripcion'];
                      echo "</option>";
                    }
                    ?>
                  </select>
                </div>
              </div>
              
              <div class="form-group">
                <label class="col-sm-2 control-label">Nº de Factura</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" 
                         name="numero_factura" 
                         placeholder="Ingrese el número de factura">
                </div>
              </div>
              
              <div class="form-group">
                <div class="col-sm-12">
                  <h4>Productos a Comprar</h4>
                  
                  <button type="button" class="btn btn-success" data-toggle="modal" data-target="#myModal">
                    <i class="fa fa-plus"></i> Agregar Producto
                  </button>
                  
                  <div class="table-responsive" style="margin-top: 15px;">
                    <table class="table table-bordered table-striped">
                        <tbody id="cuerpo-tabla-productos">
                        </tbody>
                        <tfoot>
                          <tr>
                            <td colspan="3" style="text-align: right;"><strong>TOTAL:</strong></td>
                            <td id="total-compra">0.00</td>
                            <td></td>
                          </tr>
                        </tfoot>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            <div class="box-footer">
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                  <input type="submit" class="btn btn-primary btn-submit" value="Guardar" onclick="return validarProductos();">
                  <a href="?module=compras" class="btn btn-default btn-reset">Cancelar</a>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>

  <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
          <h4 class="modal-title" id="myModalLabel">Buscar Productos</h4>
        </div>
        <div class="modal-body">
          <form class="form-horizontal">
            <div class="form-group">
              <div class="col-sm-6">
                <input type="text" class="form-control" id="buscar" placeholder="Buscar producto" onkeyup="load(1)">
              </div>
              <button type="button" class="btn btn-default" onclick="load(1)">
                <span class="glyphicon glyphicon-search"></span> Buscar producto
              </button>
            </div>
          </form>
          <div id="loader" style="position: absolute; text-align: center; top: 55px; width: 100%; display: none;"></div>
          <div class="outer_div"></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div>
  
  <script>
  function load(page){
    var buscar = document.getElementById("buscar").value;
    var loader = document.getElementById("loader");
    var outer_div = document.querySelector(".outer_div");
    
    loader.style.display = 'block';
    
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'modules/compras/buscar_productos.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    
    xhr.onload = function() {
      if (xhr.status === 200) {
        loader.style.display = 'none';
        outer_div.innerHTML = xhr.responseText;
      }
    };
    
    xhr.send('page=' + page + '&buscar=' + buscar);
  }

  function calcularTotal() {
    var total = 0;
    document.querySelectorAll('#cuerpo-tabla-productos tr').forEach(function(row) {
        var subtotalElement = row.querySelector('.subtotal');
        if (subtotalElement) {
            total += parseFloat(subtotalElement.textContent) || 0;
        }
    });
    document.getElementById('total-compra').textContent = total.toFixed(2);
  }

  function calcularSubtotal(inputElement) {
    var fila = inputElement.closest('tr'); 
    var cantidadInput = fila.querySelector('.cantidad');
    var precioInput = fila.querySelector('.precio');
    var subtotalCell = fila.querySelector('.subtotal');
    
    var cantidad = parseFloat(cantidadInput.value) || 0;
    var precio = parseFloat(precioInput.value) || 0;
    var subtotal = cantidad * precio;
    
    subtotalCell.textContent = subtotal.toFixed(2);
    calcularTotal(); 
  }

  function agregarProducto(id, nombre, precio) {
    var tabla = document.getElementById("cuerpo-tabla-productos");
    
    if (document.getElementById('fila-producto-' + id)) {
        alert('Este producto ya fue agregado a la compra.');
        return; 
    }
    
    var nuevaFila = document.createElement("tr");
    nuevaFila.id = 'fila-producto-' + id;
    
    var precioInicial = parseFloat(precio).toFixed(2); 

    nuevaFila.innerHTML = `
      <td style="width: 40%; padding-top: 15px;">
        <input type="hidden" name="productos[${id}][id_producto]" value="${id}">
        ${nombre}
      </td>
      <td style="width: 15%;">
        <input type="number" class="form-control cantidad" 
               name="productos[${id}][cantidad]" min="1" value="1" required 
               oninput="calcularSubtotal(this)">
      </td>
      <td style="width: 20%;">
        <input type="number" class="form-control precio" 
               name="productos[${id}][precio]" step="0.01" min="0" 
               value="${precioInicial}" required 
               oninput="calcularSubtotal(this)">
      </td>
      <td class="subtotal" style="width: 15%; padding-top: 15px;">${precioInicial}</td>
      <td style="width: 10%;">
        <button type="button" class="btn btn-danger btn-sm" onclick="eliminarProducto(${id})">
          <i class="fa fa-trash"></i> Eliminar
        </button>
      </td>
    `;
    tabla.appendChild(nuevaFila);
    
    $('#myModal').modal('hide');
    calcularTotal();
  }

  function eliminarProducto(id) {
    var fila = document.getElementById('fila-producto-' + id);
    if (fila) {
      fila.remove();
      calcularTotal();
    }
  }

  function validarProductos() {
    var totalFilas = document.querySelectorAll('#cuerpo-tabla-productos tr').length;
    if (totalFilas === 0) {
      alert('Debe agregar al menos un producto a la compra.');
      return false;
    }
    return true;
  }
  
  $(document).ready(function() {
      $('#myModal').on('shown.bs.modal', function () {
          load(1); 
          document.getElementById("buscar").focus();
      });
  });
  </script>

<?php 
} 
?>