<?php
if (isset($_GET['form']) && ($_GET['form'] === 'add' || $_GET['form'] === 'edit')) { 
  
  if ($_GET['form'] === 'add') {
    // Generar código automático para nueva ciudad
    $query_id = pg_query($conn, "SELECT MAX(cod_ciudad) as id FROM ciudad")
                or die('Error: '.pg_last_error($conn));
    $data_id = pg_fetch_assoc($query_id);
    $codigo = ($data_id && $data_id['id'] != null) ? (int)$data_id['id'] + 1 : 1;
    
    $descrip_ciudad = '';
    $id_departamento = '';
    $titulo = "Agregar Ciudad";
    
  } else if ($_GET['form'] === 'edit' && isset($_GET['id'])) {
    // Cargar datos existentes para editar
    $cod_ciudad = $_GET['id'];
    $query = pg_query($conn, "SELECT * FROM ciudad WHERE cod_ciudad = '$cod_ciudad'")
            or die('Error: '.pg_last_error($conn));
    $data = pg_fetch_assoc($query);
    
    $codigo = $data['cod_ciudad'];
    $descrip_ciudad = $data['descrip_ciudad'];
    $id_departamento = $data['id_departamento'];
    $titulo = "Modificar Ciudad";
  }
?>
<section class="content-header">
    <h1><i class="fa fa-edit icon-title"></i> <?php echo $titulo; ?></h1>
    <ol class="breadcrumb">
        <li><a href="?module=start"><i class="fa fa-home"></i> Inicio</a></li>
        <li><a href="?module=ciudad">Ciudad</a></li>
        <li class="active"><?php echo $titulo; ?></li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-primary">
                <form role="form" class="form-horizontal" 
                      action="modules/ciudad/proses.php?act=<?php echo ($_GET['form'] === 'add') ? 'insert' : 'update'; ?>" 
                      method="POST">
                    
                    <input type="hidden" name="cod_ciudad" value="<?php echo $codigo; ?>">
                    
                    <div class="box-body">
                        <div class="form-group">
                            <label class="col-sm-2 control-label">Código</label>
                            <div class="col-sm-2">
                                <input type="text" class="form-control" value="<?php echo $codigo; ?>" readonly>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="col-sm-2 control-label">Descripción</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" name="descrip_ciudad" 
                                       value="<?php echo htmlspecialchars($descrip_ciudad); ?>" required>
                            </div>
                            
                            <label class="col-sm-2 control-label">Departamento</label>
                            <div class="col-sm-4">
                                <select name="id_departamento" class="form-control" required>
                                    <option value="">-- Seleccionar Departamento --</option>
                                    <?php
                                    $query = pg_query($conn, "SELECT id_departamento, dep_descripcion FROM departamento ORDER BY dep_descripcion")
                                             or die("Error: ".pg_last_error($conn));
                                    while($data = pg_fetch_assoc($query)){
                                        $selected = ($id_departamento == $data['id_departamento']) ? "selected" : "";
                                        echo "<option value='".$data['id_departamento']."' $selected>".$data['dep_descripcion']."</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="box-footer">
                        <div class="form-group">
                            <div class="col-sm-offset-2 col-sm-10">
                                <input type="submit" class="btn btn-primary" value="Guardar">
                                <a href="?module=ciudad" class="btn btn-default">Cancelar</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php } ?>