<?php
session_start();
require_once "../../config/database.php";

ini_set('display_errors', 1);
error_reporting(E_ALL);

if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
    header("Location: ../../index.php?alert=3");
    exit;
} else {
    if (isset($_GET['act']) && $_GET['act'] == 'insert') {
        if (isset($_POST['cod_ciudad'], $_POST['descrip_ciudad'], $_POST['id_departamento'])) {
            $cod_ciudad      = trim($_POST['cod_ciudad']);
            $descrip_ciudad  = trim($_POST['descrip_ciudad']);
            $id_departamento = trim($_POST['id_departamento']);

            if ($cod_ciudad !== "" && $descrip_ciudad !== "" && $id_departamento !== "") {
                $sql = "INSERT INTO ciudad (cod_ciudad, descrip_ciudad, id_departamento) VALUES ($1, $2, $3)";
                $result = pg_query_params($conn, $sql, array($cod_ciudad, $descrip_ciudad, $id_departamento));

                if ($result) {
                    header("Location: ../../mind.php?module=ciudad&alert=1");
                    exit;
                } else {
                    header("Location: ../../mind.php?module=ciudad&alert=4");
                    exit;
                }
            } else {
                header("Location: ../../mind.php?module=ciudad&alert=5");
                exit;
            }
        }
    }
    elseif (isset($_GET['act']) && $_GET['act'] == 'update') {
        if (isset($_POST['cod_ciudad'], $_POST['descrip_ciudad'], $_POST['id_departamento'])) {
            $cod_ciudad      = trim($_POST['cod_ciudad']);
            $descrip_ciudad  = trim($_POST['descrip_ciudad']);
            $id_departamento = trim($_POST['id_departamento']);

            if ($cod_ciudad !== "" && $descrip_ciudad !== "" && $id_departamento !== "") {
                $sql = "UPDATE ciudad SET descrip_ciudad = $1, id_departamento = $2 WHERE cod_ciudad = $3";
                $result = pg_query_params($conn, $sql, array($descrip_ciudad, $id_departamento, $cod_ciudad));

                if ($result) {
                    header("Location: ../../mind.php?module=ciudad&alert=2");
                    exit;
                } else {
                    header("Location: ../../mind.php?module=ciudad&alert=4");
                    exit;
                }
            } else {
                header("Location: ../../mind.php?module=ciudad&alert=5");
                exit;
            }
        }
    }
    elseif (isset($_GET['act']) && $_GET['act'] == 'delete') {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];

            $sql = "DELETE FROM ciudad WHERE cod_ciudad = $1";
            $result = pg_query_params($conn, $sql, array($id));

            if ($result) {
                header("Location: ../../mind.php?module=ciudad&alert=3");
                exit;
            } else {
                header("Location: ../../mind.php?module=ciudad&alert=4");
                exit;
            }
        }
    }
}
?>