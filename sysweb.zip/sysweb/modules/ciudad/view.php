<section class="content-header">
  <ol class="breadcrumb">
    <li><a href="?module=start" class="fa fa-home"><i></i>Inicio</a></li>
    <li class="active"><a href="?module=ciudad">Ciudad</a></li>
  </ol>
  <h1>
    <i class="fa fa-folder icon-title"></i> Datos de ciudades
    <a class="btn btn-primary btn-social pull-right" href="?module=form_ciudad&form=add" title="Agregar" data-toggle="tooltip">
      <i class="fa fa-plus"></i> Agregar
    </a>
  </h1>
</section>

<section class="content">
  <div class="row">
    <div class="col-md-12">
      <?php
        if (!empty($_GET['alert'])) {
          switch ($_GET['alert']) {
            case 1:
              echo "<div class='alert alert-success alert-dismissable'>
                      <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                      <h4><i class='icon fa fa-check-circle'></i> Exitoso!</h4>
                      Datos registrados correctamente
                    </div>";
              break;
            case 2:
              echo "<div class='alert alert-success alert-dismissable'>
                      <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                      <h4><i class='icon fa fa-check-circle'></i> Exitoso!</h4>
                      Datos modificados correctamente
                    </div>";
              break;
            case 3:
              echo "<div class='alert alert-success alert-dismissable'>
                      <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                      <h4><i class='icon fa fa-check-circle'></i> Exitoso!</h4>
                      Datos eliminados correctamente
                    </div>";
              break;
            case 4:
              echo "<div class='alert alert-danger alert-dismissable'>
                      <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                      <h4><i class='icon fa fa-times-circle'></i> Error!</h4>
                      No se pudo realizar la operación correctamente
                    </div>";
              break;
            case 5:
              echo "<div class='alert alert-warning alert-dismissable'>
                      <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                      <h4><i class='icon fa fa-exclamation-triangle'></i> Atención!</h4>
                      Los campos no pueden estar vacíos
                    </div>";
              break;
          }
        }
      ?>

      <div class="box box-primary">
        <div class="box-body">
          <h2>Lista de Ciudades</h2>

          <div class="form-inline" style="margin-bottom:10px;">
            <label for="registros">Mostrar </label>
            <select id="registros" class="form-control input-sm">
              <option value="5">5</option>
              <option value="10" selected>10</option>
              <option value="25">25</option>
              <option value="50">50</option>
              <option value="100">100</option>
            </select>
            <label> registros</label>

            <div class="pull-right">
              <label for="buscar">Buscar: </label>
              <input type="text" id="buscar" class="form-control input-sm" placeholder="Escribe para buscar...">
            </div>
          </div>

          <table id="dataTables1" class="table table-bordered table-striped table-hover">
            <thead>
              <tr>
                <th class="center">Código</th>
                <th class="center">Descripción</th>
                <th class="center">Departamento</th>
                <th class="center">Acción</th>
              </tr>
            </thead>
            <tbody>
              <?php
                $query = pg_query($conn, "SELECT cod_ciudad, descrip_ciudad, dep.id_departamento, dep.dep_descripcion
                                          FROM ciudad ciu
                                          JOIN departamento dep ON ciu.id_departamento = dep.id_departamento")
                  or die("Error: ".pg_last_error($conn));
                
                while ($data = pg_fetch_assoc($query)) {
                  $cod_ciudad = $data['cod_ciudad'];
                  $descrip_ciudad = $data['descrip_ciudad'];
                  $dep_descripcion = $data['dep_descripcion'];
                  $id_departamento = $data['id_departamento'];

                  echo "<tr>
                          <td class='center'>$cod_ciudad</td>
                          <td class='center'>$descrip_ciudad</td>
                          <td class='center'>$dep_descripcion</td>
                          <td class='center' width='120'>
                            <div>
                              <a data-toggle='tooltip' data-placement='top' title='Modificar' style='margin-right:5px'
                                class='btn btn-primary btn-sm' href='?module=form_ciudad&form=edit&id=$cod_ciudad'>
                                <i class='glyphicon glyphicon-edit' style='color:#fff'></i>
                              </a>
                              <a data-toggle='tooltip' data-placement='top' title='Eliminar' class='btn btn-danger btn-sm'
                                href='modules/ciudad/proses.php?act=delete&id=$cod_ciudad'
                                onclick='return confirm(\"¿Estás seguro/a de eliminar la ciudad: $descrip_ciudad?\");'>
                                <i class='glyphicon glyphicon-trash'></i>
                              </a>
                            </div>
                          </td>
                        </tr>";
                }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</section>