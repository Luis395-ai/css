<?php
if (isset($_GET['form']) && $_GET['form'] === 'add') { 
  $query_id = pg_query($conn, "SELECT MAX(id_cliente) as id FROM clientes")
              or die('Error: '.pg_last_error($conn));
  $data_id = pg_fetch_assoc($query_id);
  $codigo = ($data_id && $data_id['id'] != null) ? $data_id['id'] + 1 : 1;
?>
  <section class="content-header">
    <h1><i class="fa fa-edit icon-title"></i> Agregar Cliente</h1>
    <ol class="breadcrumb">
      <li><a href="?module=start"><i class="fa fa-home"></i> Inicio</a></li>
      <li><a href="?module=clientes">Clientes</a></li>
      <li class="active">Agregar</li>
    </ol>
  </section>

  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <form role="form" class="form-horizontal" 
                action="modules/clientes/proses.php?act=insert" 
                method="POST">
            <div class="box-body">
              <div class="form-group">
                <label class="col-sm-2 control-label">Código</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" 
                         name="id_cliente" 
                         value="<?php echo htmlspecialchars($codigo); ?>" readonly>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">CI/RUC</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" 
                         name="ci_ruc" 
                         placeholder="Ingresa CI o RUC" required>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Nombre</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" 
                         name="cli_nombre" 
                         placeholder="Ingresa el nombre" required>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Apellido</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" 
                         name="cli_apellido" 
                         placeholder="Ingresa el apellido" required>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Dirección</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" 
                         name="cli_direccion" 
                         placeholder="Ingresa la dirección">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Teléfono</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" 
                         name="cli_telefono" 
                         placeholder="Ingresa el teléfono">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Ciudad</label>
                <div class="col-sm-5">
                  <select name="cod_ciudad" class="form-control" required>
                    <option value=""></option>
                    <?php
                    $query = pg_query($conn, "SELECT * FROM ciudad")
                             or die("Error: ".pg_last_error($conn));
                    while($data = pg_fetch_assoc($query)){
                      echo "<option value='".$data['cod_ciudad']."'";
                      if(isset($_POST['cod_ciudad']) && $_POST['cod_ciudad'] == $data['cod_ciudad']) {
                        echo " SELECTED";
                      }
                      echo ">";
                      echo $data['descrip_ciudad'];
                      echo "</option>";
                    }
                    ?>
                  </select>
                </div>
              </div>
            </div>
            <div class="box-footer">
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                  <input type="submit" class="btn btn-primary btn-submit" value="Guardar">
                  <a href="?module=clientes" class="btn btn-default btn-reset">Cancelar</a>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>

<?php 
} elseif (isset($_GET['form']) && $_GET['form'] === 'edit') { 
  $id_cliente = "";
  $ci_ruc = "";
  $cli_nombre = "";
  $cli_apellido = "";
  $cli_direccion = "";
  $cli_telefono = "";
  $cod_ciudad = "";

  if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = (int) $_GET['id'];
    $query = pg_query($conn, "SELECT * FROM clientes WHERE id_cliente = $id")
             or die('Error: '.pg_last_error($conn));
    if ($data = pg_fetch_assoc($query)) {
      $id_cliente = $data['id_cliente'];
      $ci_ruc = $data['ci_ruc'];
      $cli_nombre = $data['cli_nombre'];
      $cli_apellido = $data['cli_apellido'];
      $cli_direccion = $data['cli_direccion'];
      $cli_telefono = $data['cli_telefono'];
      $cod_ciudad = $data['cod_ciudad'];
    }
  }
?>
  <section class="content-header">
    <h1><i class="fa fa-edit icon-title"></i> Modificar Cliente</h1>
    <ol class="breadcrumb">
      <li><a href="?module=start"><i class="fa fa-home"></i> Inicio</a></li>
      <li><a href="?module=clientes">Clientes</a></li>
      <li class="active">Modificar</li>
    </ol>
  </section>

  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <form role="form" class="form-horizontal" 
                action="modules/clientes/proses.php?act=update" 
                method="POST">
            <div class="box-body">
              <div class="form-group">
                <label class="col-sm-2 control-label">Código</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" 
                         name="id_cliente" 
                         value="<?php echo htmlspecialchars($id_cliente); ?>" readonly>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">CI/RUC</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" 
                         name="ci_ruc" required
                         value="<?php echo htmlspecialchars($ci_ruc); ?>">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Nombre</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" 
                         name="cli_nombre" required
                         value="<?php echo htmlspecialchars($cli_nombre); ?>">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Apellido</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" 
                         name="cli_apellido" required
                         value="<?php echo htmlspecialchars($cli_apellido); ?>">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Dirección</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" 
                         name="cli_direccion"
                         value="<?php echo htmlspecialchars($cli_direccion); ?>">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Teléfono</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" 
                         name="cli_telefono"
                         value="<?php echo htmlspecialchars($cli_telefono); ?>">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Ciudad</label>
                <div class="col-sm-5">
                  <select name="cod_ciudad" class="form-control" required>
                    <option value=""></option>
                    <?php
                    $query = pg_query($conn, "SELECT * FROM ciudad")
                             or die("Error: ".pg_last_error($conn));
                    while($data = pg_fetch_assoc($query)){
                      echo "<option value='".$data['cod_ciudad']."'";
                      if($cod_ciudad == $data['cod_ciudad']) {
                        echo " SELECTED";
                      }
                      echo ">";
                      echo $data['descrip_ciudad'];
                      echo "</option>";
                    }
                    ?>
                  </select>
                </div>
              </div>
            </div>
            <div class="box-footer">
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                  <input type="submit" class="btn btn-primary btn-submit" value="Guardar">
                  <a href="?module=clientes" class="btn btn-default btn-reset">Cancelar</a>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
<?php 
} 
?>