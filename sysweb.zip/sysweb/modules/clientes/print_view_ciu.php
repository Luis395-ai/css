<?php
require_once "../../config/database.php";
$query = pg_query($conn, "
    SELECT 
        cli.id_cliente,
        cli.ci_ruc,
        cli.cli_nombre,
        cli.cli_apellido,
        cli.cli_direccion,
        cli.cli_telefono,
        ciu.descrip_ciudad,
        dep.dep_descripcion
    FROM clientes cli
    LEFT JOIN ciudad ciu ON cli.cod_ciudad = ciu.cod_ciudad
    LEFT JOIN departamento dep ON ciu.id_departamento = dep.id_departamento
    ORDER BY cli.id_cliente ASC
") or die("Error: ".pg_last_error($conn));
$count = pg_num_rows($query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reporte de Clientes</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            font-size: 11px;
        }
        th, td {
            border: 1px solid #333;
            padding: 5px;
            text-align: center;
        }
        th {
            background: #f2f2f2;
            font-weight: bold;
        }
        th.codigo, td.codigo {
            width: 6%;
        }
        th.ci_ruc, td.ci_ruc {
            width: 10%;
        }
        th.nombre, td.nombre {
            width: 12%;
        }
        th.apellido, td.apellido {
            width: 12%;
        }
        th.direccion, td.direccion {
            width: 18%;
        }
        th.telefono, td.telefono {
            width: 10%;
        }
        th.ciudad, td.ciudad {
            width: 12%;
        }
        th.departamento, td.departamento {
            width: 20%;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .cabecera-img {
            display: block;
            margin: 0 auto 20px auto;
            max-width: 120px;
        }
        .total {
            font-weight: bold;
            text-align: center;
            margin-top: 10px;
        }
        /* Para texto largo que pueda desbordar */
        td {
            word-wrap: break-word;
            max-width: 0;
            overflow: hidden;
        }
    </style>
</head>
<body>
    <img src="../../assets/img/log.png" alt="Icono" class="cabecera-img">
    <h2>Reporte de Clientes</h2>
    <table>
        <thead>
            <tr>
                <th class="codigo">Código</th>
                <th class="ci_ruc">CI/RUC</th>
                <th class="nombre">Nombre</th>
                <th class="apellido">Apellido</th>
                <th class="direccion">Dirección</th>
                <th class="telefono">Teléfono</th>
                <th class="ciudad">Ciudad</th>
                <th class="departamento">Departamento</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($data = pg_fetch_assoc($query)) {
                echo "<tr>
                        <td class='codigo'>{$data['id_cliente']}</td>
                        <td class='ci_ruc'>{$data['ci_ruc']}</td>
                        <td class='nombre'>{$data['cli_nombre']}</td>
                        <td class='apellido'>{$data['cli_apellido']}</td>
                        <td class='direccion'>{$data['cli_direccion']}</td>
                        <td class='telefono'>{$data['cli_telefono']}</td>
                        <td class='ciudad'>{$data['descrip_ciudad']}</td>
                        <td class='departamento'>{$data['dep_descripcion']}</td>
                      </tr>";
            }
            ?>
        </tbody>
    </table>
    <p class="total">Total de clientes: <?php echo $count; ?></p>
</body>
</html>