<?php
session_start();
require_once "../../config/database.php";

ini_set('display_errors', 1);
error_reporting(E_ALL);

if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
    header("Location: ../../index.php?alert=3");
    exit;
} else {
    if (isset($_GET['act']) && $_GET['act'] == 'insert') {
        if (isset($_POST['id_cliente'], $_POST['ci_ruc'], $_POST['cli_nombre'], $_POST['cli_apellido'], $_POST['cod_ciudad'])) {
            $id_cliente    = trim($_POST['id_cliente']);
            $ci_ruc        = trim($_POST['ci_ruc']);
            $cli_nombre    = trim($_POST['cli_nombre']);
            $cli_apellido  = trim($_POST['cli_apellido']);
            $cli_direccion = isset($_POST['cli_direccion']) ? trim($_POST['cli_direccion']) : '';
            $cli_telefono  = isset($_POST['cli_telefono']) ? trim($_POST['cli_telefono']) : '';
            $cod_ciudad    = trim($_POST['cod_ciudad']);

            if ($id_cliente !== "" && $ci_ruc !== "" && $cli_nombre !== "" && $cli_apellido !== "" && $cod_ciudad !== "") {
                $sql = "INSERT INTO clientes (id_cliente, ci_ruc, cli_nombre, cli_apellido, cli_direccion, cli_telefono, cod_ciudad) 
                        VALUES ($1, $2, $3, $4, $5, $6, $7)";
                $result = pg_query_params($conn, $sql, array(
                    $id_cliente, $ci_ruc, $cli_nombre, $cli_apellido, 
                    $cli_direccion, $cli_telefono, $cod_ciudad
                ));

                if ($result) {
                    header("Location: ../../mind.php?module=clientes&alert=1");
                    exit;
                } else {
                    header("Location: ../../mind.php?module=clientes&alert=4");
                    exit;
                }
            } else {
                header("Location: ../../mind.php?module=clientes&alert=5");
                exit;
            }
        }
    }
    elseif (isset($_GET['act']) && $_GET['act'] == 'update') {
        if (isset($_POST['id_cliente'], $_POST['ci_ruc'], $_POST['cli_nombre'], $_POST['cli_apellido'], $_POST['cod_ciudad'])) {
            $id_cliente    = trim($_POST['id_cliente']);
            $ci_ruc        = trim($_POST['ci_ruc']);
            $cli_nombre    = trim($_POST['cli_nombre']);
            $cli_apellido  = trim($_POST['cli_apellido']);
            $cli_direccion = isset($_POST['cli_direccion']) ? trim($_POST['cli_direccion']) : '';
            $cli_telefono  = isset($_POST['cli_telefono']) ? trim($_POST['cli_telefono']) : '';
            $cod_ciudad    = trim($_POST['cod_ciudad']);

            if ($id_cliente !== "" && $ci_ruc !== "" && $cli_nombre !== "" && $cli_apellido !== "" && $cod_ciudad !== "") {
                $sql = "UPDATE clientes 
                        SET ci_ruc = $1, cli_nombre = $2, cli_apellido = $3, 
                            cli_direccion = $4, cli_telefono = $5, cod_ciudad = $6 
                        WHERE id_cliente = $7";
                $result = pg_query_params($conn, $sql, array(
                    $ci_ruc, $cli_nombre, $cli_apellido, $cli_direccion, 
                    $cli_telefono, $cod_ciudad, $id_cliente
                ));

                if ($result) {
                    header("Location: ../../mind.php?module=clientes&alert=2");
                    exit;
                } else {
                    header("Location: ../../mind.php?module=clientes&alert=4");
                    exit;
                }
            } else {
                header("Location: ../../mind.php?module=clientes&alert=5");
                exit;
            }
        }
    }
    elseif (isset($_GET['act']) && $_GET['act'] == 'delete') {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];

            $sql = "DELETE FROM clientes WHERE id_cliente = $1";
            $result = pg_query_params($conn, $sql, array($id));

            if ($result) {
                header("Location: ../../mind.php?module=clientes&alert=3");
                exit;
            } else {
                header("Location: ../../mind.php?module=clientes&alert=4");
                exit;
            }
        }
    }
}
?>