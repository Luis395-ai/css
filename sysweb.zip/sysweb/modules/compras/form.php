<?php
if (isset($_GET['form']) && $_GET['form'] === 'add') { 
    $query_id = pg_query($conn, "SELECT MAX(cod_compra) as id FROM compra")
        or die('Error: '.pg_last_error($conn));
    $data_id = pg_fetch_assoc($query_id);
    $codigo = ($data_id && $data_id['id'] != null) ? $data_id['id'] + 1 : 1;
?>
<section class="content-header">
    <h1><i class="fa fa-edit icon-title"></i> Agregar Compra</h1>
</section>
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-primary">
                <form role="form" class="form-horizontal" 
                      action="modules/compras/proses.php?act=insert" 
                      method="POST">
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-4">
                                <label>Código</label>
                                <input type="text" name="cod_compra" class="form-control" 
                                       value="<?php echo $codigo; ?>" readonly>
                            </div>
                            <div class="col-md-4">
                                <label>Fecha</label>
                                <input type="date" name="fecha" class="form-control" 
                                       value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            <div class="col-md-4">
                                <label>Hora</label>
                                <input type="time" name="hora" class="form-control" 
                                       value="<?php echo date('H:i'); ?>" required>
                            </div>
                        </div>

                        <div class="row" style="margin-top:10px;">
                            <div class="col-md-6">
                                <label>Proveedor</label>
                                <select name="cod_proveedor" class="form-control" required>
                                    <option value="">- Seleccionar Proveedor -</option>
                                    <?php
                                    $query = pg_query($conn, "SELECT * FROM proveedor");
                                    while($prov = pg_fetch_assoc($query)){
                                        echo "<option value='{$prov['cod_proveedor']}'>{$prov['razon_social']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label>N° de Factura</label>
                                <input type="text" name="nro_factura" class="form-control" required>
                            </div>
                        </div>

                        <div class="row" style="margin-top:10px;">
                            <div class="col-md-6">
                                <label>Depósito</label>
                                <select name="cod_deposito" class="form-control" required>
                                    <option value="">- Seleccionar Depósito -</option>
                                    <?php
                                    $query = pg_query($conn, "SELECT * FROM deposito");
                                    while($dep = pg_fetch_assoc($query)){
                                        echo "<option value='{$dep['cod_deposito']}'>{$dep['descrip']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <hr>
                        <h4>Productos</h4>
                        <button type="button" class="btn btn-info" id="agregar-producto">
                            <i class="fa fa-plus"></i> Agregar Producto
                        </button>
                        <div class="table-responsive" style="margin-top:10px;">
                            <table class="table table-bordered" id="detalles-table">
                                <thead>
                                    <tr>
                                        <th>Producto</th>
                                        <th>Cantidad</th>
                                        <th>Precio</th>
                                        <th>Subtotal</th>
                                        <th>Acción</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                        <div class="row" style="margin-top:10px;">
                            <div class="col-md-4 col-md-offset-8">
                                <label>Total Compra</label>
                                <input type="text" class="form-control" id="total_display" readonly>
                                <input type="hidden" name="total_compra" id="total_compra">
                            </div>
                        </div>

                    </div>

                    <div class="box-footer">
                        <input type="submit" class="btn btn-primary" value="Guardar">
                        <a href="?module=compras" class="btn btn-default">Cancelar</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<div class="modal fade" id="modalBuscar">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Buscar Productos</h4>
            </div>
            <div class="modal-body">
                <input type="text" class="form-control" id="buscarInput" placeholder="Buscar productos...">

                <div class="table-responsive" style="max-height:300px; margin-top:10px;">
                    <table class="table table-bordered" id="tablaProductos">
                        <thead>
                            <tr>
                                <th>Producto</th>
                                <th>Precio</th>
                                <th>Acción</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $query = pg_query($conn, "SELECT p.cod_producto, p.p_descrip, p.precio
                                                 FROM producto p");
                        while($prod = pg_fetch_assoc($query)){
                            echo "<tr>
                                    <td>{$prod['p_descrip']}</td>
                                    <td>{$prod['precio']}</td>
                                    <td>
                                        <button type='button' class='btn btn-success btn-xs btn-seleccionar'
                                            data-id='{$prod['cod_producto']}'
                                            data-nombre='{$prod['p_descrip']}'
                                            data-precio='{$prod['precio']}'>Seleccionar</button>
                                    </td>
                                  </tr>";
                        }
                        ?>
                        </tbody>
                    </table>
                </div>

                <div id="formProducto" style="display:none; margin-top:10px;">
                    <h5>Producto: <span id="productoNombre"></span></h5>
                    <div class="row">
                        <div class="col-md-4">
                            <label>Cantidad</label>
                            <input type="number" class="form-control" id="productoCantidad" value="1" min="1">
                        </div>
                        <div class="col-md-4">
                            <label>Precio</label>
                            <input type="number" class="form-control" id="productoPrecio" step="0.01" min="0">
                        </div>
                        <div class="col-md-4">
                            <label>Subtotal</label>
                            <input type="text" class="form-control" id="productoSubtotal" readonly>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="agregarBtn" style="display:none;">Agregar</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#agregar-producto').click(function(){
        $('#modalBuscar').modal('show');
    });
    $('#buscarInput').on('keyup', function(){
        var value = $(this).val().toLowerCase();
        $('#tablaProductos tbody tr').filter(function(){
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });
    $(document).on('click', '.btn-seleccionar', function(){
        var id = $(this).data('id');
        var nombre = $(this).data('nombre');
        var precio = $(this).data('precio');

        $('#productoNombre').text(nombre);
        $('#productoPrecio').val(precio);
        $('#formProducto').show();
        $('#agregarBtn').show().data('id', id);

        calcularSubtotal();
    });
    function calcularSubtotal(){
        var cantidad = parseFloat($('#productoCantidad').val()) || 0;
        var precio = parseFloat($('#productoPrecio').val()) || 0;
        $('#productoSubtotal').val((cantidad*precio).toFixed(2));
    }

    $('#productoCantidad, #productoPrecio').on('input', calcularSubtotal);
    $('#agregarBtn').click(function(){
        var id = $(this).data('id');
        var nombre = $('#productoNombre').text();
        var cantidad = $('#productoCantidad').val();
        var precio = $('#productoPrecio').val();
        var subtotal = $('#productoSubtotal').val();
        var fila = `<tr>
            <td>${nombre}<input type="hidden" name="productos[]" value="${id}"></td>
            <td>${cantidad}<input type="hidden" name="cantidades[]" value="${cantidad}"></td>
            <td>${precio}<input type="hidden" name="precios[]" value="${precio}"></td>
            <td>${subtotal}</td>
            <td><button type="button" class="btn btn-danger btn-xs btn-eliminar">Eliminar</button></td>
        </tr>`;
        $('#detalles-table tbody').append(fila);
        $('#modalBuscar').modal('hide');
        limpiarModal();
        actualizarTotal();
    });
    $(document).on('click', '.btn-eliminar', function(){
        $(this).closest('tr').remove();
        actualizarTotal();
    });
    function limpiarModal(){
        $('#buscarInput').val('');
        $('#productoCantidad').val(1);
        $('#productoPrecio').val('');
        $('#productoSubtotal').val('');
        $('#formProducto').hide();
        $('#agregarBtn').hide().data('id','');
        $('#tablaProductos tbody tr').show();
    }

    $('#modalBuscar').on('hidden.bs.modal', limpiarModal);
    function actualizarTotal() {
        var total = 0;
        $('#detalles-table tbody tr').each(function(){
            var subtotal = parseFloat($(this).find('td:eq(3)').text()) || 0;
            total += subtotal;
        });
        $('#total_display').val(total.toFixed(2));
        $('#total_compra').val(total.toFixed(2));
    }
});
</script>

<?php 
} 
?>
