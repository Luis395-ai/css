<?php
if (isset($_GET['form']) && $_GET['form'] === 'add') { 
    $query_id = pg_query($conn, "SELECT MAX(cod_compra) as id FROM compra")
        or die('Error: '.pg_last_error($conn));
    $data_id = pg_fetch_assoc($query_id);
    $codigo = ($data_id && $data_id['id'] != null) ? $data_id['id'] + 1 : 1;
?>
<section class="content-header">
    <h1><i class="fa fa-edit icon-title"></i> Agregar Compra</h1>
    <ol class="breadcrumb">
        <li><a href="?module=start"><i class="fa fa-home"></i> Inicio</a></li>
        <li><a href="?module=compras">Compras</a></li>
        <li class="active">Agregar</li>
    </ol>
</section>

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-primary">
                <form role="form" class="form-horizontal" action="modules/compras/proses.php?act=insert" method="POST" id="form_compra">
                    <div class="box-body">
                        <div class="form-group">
                            <label class="col-sm-2 control-label">Código</label>
                            <div class="col-sm-2">
                                <input type="text" class="form-control" name="cod_compra" value="<?php echo $codigo; ?>" readonly>
                            </div>
                            <label class="col-sm-1 control-label">Fecha</label>
                            <div class="col-sm-2">
                                <input type="date" class="form-control" name="fecha" value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            <label class="col-sm-1 control-label">Hora</label>
                            <div class="col-sm-2">
                                <input type="time" class="form-control" name="hora" value="<?php echo date('H:i'); ?>" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-2 control-label">Proveedor</label>
                            <div class="col-sm-4">
                                <select name="cod_proveedor" class="form-control" required>
                                    <option value="">- Seleccionar Proveedor -</option>
                                    <?php
                                    $query = pg_query($conn, "SELECT * FROM proveedor");
                                    while($prov = pg_fetch_assoc($query)){
                                        echo "<option value='{$prov['cod_proveedor']}'>{$prov['razon_social']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>

                            <label class="col-sm-2 control-label">Depósito</label>
                            <div class="col-sm-4">
                                <select name="cod_deposito" class="form-control" required>
                                    <option value="">- Seleccionar Depósito -</option>
                                    <?php
                                    $query = pg_query($conn, "SELECT * FROM deposito");
                                    while($dep = pg_fetch_assoc($query)){
                                        echo "<option value='{$dep['cod_deposito']}'>{$dep['descrip']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-2 control-label">N° de Factura</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" name="nro_factura" required>
                            </div>
                        </div>

                        <hr>
                        <div class="form-group">
                            <div class="col-sm-12">
                                <h4>Productos a Comprar</h4>
                                <button type="button" class="btn btn-success" id="btnAgregarProducto">
                                    <i class="fa fa-plus"></i> Agregar Producto
                                </button>

                                <div class="table-responsive" style="margin-top: 15px;">
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>Producto</th>
                                                <th>Cantidad</th>
                                                <th>Precio</th>
                                                <th>Subtotal</th>
                                                <th>Acción</th>
                                            </tr>
                                        </thead>
                                        <tbody id="detalles-table"></tbody>
                                        <tfoot>
                                            <tr>
                                                <td colspan="3" style="text-align: right;"><strong>TOTAL:</strong></td>
                                                <td id="total_display">0.00</td>
                                                <input type="hidden" name="total_compra" id="total_compra" value="0">
                                                <td></td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="box-footer">
                        <div class="form-group">
                            <div class="col-sm-offset-2 col-sm-10">
                                <input type="submit" class="btn btn-primary btn-submit" value="Guardar">
                                <a href="?module=compras" class="btn btn-default btn-reset">Cancelar</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<div class="modal fade bs-example-modal-lg" id="modalProductos" tabindex="-1" role="dialog" aria-labelledby="modalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                <h4 class="modal-title" id="modalLabel">Buscar Productos</h4>
            </div>
            <div class="modal-body">
                <div class="form-horizontal">
                    <div class="form-group">
                        <div class="col-sm-8">
                            <input type="text" class="form-control" id="x" placeholder="Buscar productos" onkeyup="load(1)">
                        </div>
                        <button type="button" class="btn btn-default" onclick="load(1)">
                            <span class="glyphicon glyphicon-search"></span> Buscar
                        </button>
                    </div>
                </div>
                <div id="loader" style="position: absolute; text-align: center; top: 55px; width: 100%; display:none;"></div>
                <div class="outer_div"></div>
                <div id="resultados" style="margin-top:10px;"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

<script>
$(document).ready(function(){
    $('#btnAgregarProducto').click(function(e){
        e.preventDefault();
        $('#modalProductos').modal('show');
        load(1);
    });
});

function load(page){
    var x = $("#x").val();
    var parameters = {"action":"ajax","page":page, "x":x};
    $(".outer_div").fadeOut('slow');
    $("#loader").show();

    
    var ajaxUrl = 'ajax/products_pedido.php';

    $("#loader").html('<div style="text-align:center; padding:20px;"><i class="fa fa-spinner fa-spin fa-2x"></i><br>Cargando productos...</div>');

    $.ajax({
        url: ajaxUrl,
        type: 'POST',
        data: parameters,
        success: function(data){
            $(".outer_div").html(data).fadeIn('slow');
            $("#loader").html('');
        },
        error: function(xhr, status, error){
            $("#loader").html('<div style="color:red; padding:20px; text-align:center;">' +
                            '<i class="fa fa-exclamation-triangle fa-2x"></i><br>' +
                            'Error al cargar productos<br>' +
                            '<small>Archivo: ' + ajaxUrl + '</small><br>' +
                            '<small>Error: ' + error + '</small>' +
                            '</div>');
            console.log('Error AJAX:', error);
            console.log('URL:', ajaxUrl);
            console.log('Status:', status);
        }
    });
}

function agregarProducto(id){
    event.preventDefault();
    event.stopPropagation();

    var precio_compra = $("#precio_compra_"+id).val().replace(/,/g, '');
    var cantidad = $("#cantidad_"+id).val();

    if(isNaN(cantidad) || cantidad <= 0){
        alert("Cantidad inválida");
        $("#cantidad_"+id).focus();
        return false;
    }

    if(isNaN(precio_compra) || precio_compra <= 0){
        alert("Precio inválido");
        $("#precio_compra_"+id).focus();
        return false;
    }

    var filaProducto = $("#precio_compra_"+id).closest('tr');
    var nombre = filaProducto.find('td:eq(1)').text().trim();
    var codigo = filaProducto.find('td:eq(0)').text().trim();
    var subtotal = (parseFloat(cantidad) * parseFloat(precio_compra)).toFixed(2);

    if ($("#fila_"+id).length) {
        alert("Este producto ya fue agregado");
        return false;
    }

    var fila = `<tr id="fila_${id}">
        <td>${codigo} - ${nombre}<input type="hidden" name="productos[]" value="${id}"></td>
        <td>${cantidad}<input type="hidden" name="cantidades[]" value="${cantidad}"></td>
        <td>${precio_compra}<input type="hidden" name="precios[]" value="${precio_compra}"></td>
        <td>${subtotal}</td>
        <td><button type="button" class="btn btn-danger btn-xs" onclick="eliminar(${id})">Eliminar</button></td>
    </tr>`;

    $('#detalles-table').append(fila);
    actualizarTotal();

    $("#resultados").html('<div class="alert alert-success">Producto agregado correctamente</div>');
    setTimeout(()=>$("#resultados").html(''),2000);
    return false;
}

function eliminar(id){
    event.preventDefault();
    $("#fila_"+id).remove();
    actualizarTotal();
    $("#resultados").html('<div class="alert alert-info">Producto eliminado</div>');
    setTimeout(()=>$("#resultados").html(''),2000);
}

function actualizarTotal() {
    var total = 0;
    $('#detalles-table tr').each(function(){
        var subtotal = parseFloat($(this).find('td:eq(3)').text());
        if(!isNaN(subtotal)) total += subtotal;
    });
    $("#total_display").text(total.toFixed(2));
    $("#total_compra").val(total.toFixed(2));
}

$('#modalProductos form').on('submit', function(e){
    e.preventDefault();
});
</script>
<?php } ?>