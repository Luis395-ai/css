<?php 
require_once '../../assets/plugins/vendor/autoload.php';
use Spipu\Html2Pdf\Html2Pdf;
$id_compra = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id_compra > 0) {
    ob_start();
    include 'print_view.php';
    $html = ob_get_clean();

    $html2pdf = new Html2Pdf('P', 'A4', 'es');
    $html2pdf->writeHTML($html);
    $html2pdf->output('compra_'.$id_compra.'.pdf');
} else {
    die("Error: No se especificó la compra a imprimir");
}
?>