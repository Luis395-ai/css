<?php
require_once "../../config/database.php";

$id_compra = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id_compra <= 0) {
    die("Error: ID de compra no válido");
}

// Obtener datos de la compra (incluye depósito y proveedor)
$query_compra = pg_query($conn, "
    SELECT c.cod_compra, c.nro_factura, c.fecha, c.hora,
           p.razon_social, d.descrip AS deposito, u.name_user
    FROM compra c
    JOIN proveedor p ON c.cod_proveedor = p.cod_proveedor
    JOIN deposito d ON c.cod_deposito = d.cod_deposito
    LEFT JOIN usuarios u ON c.id_user = u.id_user
    WHERE c.cod_compra = $id_compra
") or die("Error: ".pg_last_error($conn));

$compra = pg_fetch_assoc($query_compra);
if (!$compra) {
    die("Error: Compra no encontrada");
}

// Obtener detalles de la compra desde la vista
$query_detalles = pg_query($conn, "
    SELECT *
    FROM v_det_compra
    WHERE cod_compra = $id_compra
    ORDER BY t_p_descrip, p_descrip
") or die("Error: ".pg_last_error($conn));
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Factura de Compra <?php echo $compra['cod_compra']; ?></title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; line-height: 1.4; }
     .header {
    text-align: left;
    margin-bottom: 20px;
    border-bottom: 2px solid #333;
    padding-bottom: 10px;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.logo {
    max-width: 30px;
    margin-bottom: 5px;
}

.titulo {
    font-size: 18px;
    font-weight: bold;
    margin: 0;
}

        .info-compra { width: 100%; margin-bottom: 20px; border-collapse: collapse; }
        .info-compra td { padding: 5px; vertical-align: top; }
        .info-compra .label { font-weight: bold; width: 30%; }
        .tabla-detalles { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        .tabla-detalles th { background: #f2f2f2; border: 1px solid #333; padding: 8px; text-align: center; font-weight: bold; }
        .tabla-detalles td { border: 1px solid #333; padding: 8px; text-align: center; }
        .total { text-align: right; font-weight: bold; font-size: 14px; margin-top: 20px; }
        .footer { margin-top: 30px; text-align: center; font-size: 10px; color: #666; }
        .col-tipo { width: 20%; }
        .col-producto { width: 25%; }
        .col-unidad { width: 15%; }
        .col-precio { width: 15%; }
        .col-cantidad { width: 10%; }
        .col-subtotal { width: 15%; }
    </style>
</head>
<body>
    <div class="header">
        <img src="../../assets/img/log.png" alt="Logo" class="logo">
        <div class="titulo">REGISTRO DE FACTURA DE COMPRA</div>
    </div>

    <table class="info-compra">
        <tr>
            <td class="label">Proveedor:</td>
            <td><?php echo htmlspecialchars($compra['razon_social']); ?></td>
        </tr>
        <tr>
            <td class="label">Depósito:</td>
            <td><?php echo htmlspecialchars($compra['deposito']); ?></td>
        </tr>
        <tr>
            <td class="label">Nº de Factura:</td>
            <td><?php echo htmlspecialchars($compra['nro_factura']); ?></td>
        </tr>
        <tr>
            <td class="label">Fecha:</td>
            <td><?php echo htmlspecialchars($compra['fecha']); ?></td>
        </tr>
        <tr>
            <td class="label">Hora:</td>
            <td><?php echo htmlspecialchars($compra['hora']); ?></td>
        </tr>
        <?php if (!empty($compra['name_user'])): ?>
        <tr>
            <td class="label">Usuario:</td>
            <td><?php echo htmlspecialchars($compra['name_user']); ?></td>
        </tr>
        <?php endif; ?>
    </table>

    <table class="tabla-detalles">
        <thead>
            <tr>
                <th class="col-tipo">Tipo de Producto</th>
                <th class="col-producto">Producto</th>
                <th class="col-unidad">Unidad de Medida</th>
                <th class="col-precio">Precio</th>
                <th class="col-cantidad">Cantidad</th>
                <th class="col-subtotal">Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $total_general = 0;
            while ($detalle = pg_fetch_assoc($query_detalles)) {
                $precio = isset($detalle['precio']) ? (float)$detalle['precio'] : 0;
                $cantidad = isset($detalle['cantidad']) ? (float)$detalle['cantidad'] : 0;
                $subtotal = $precio * $cantidad;
                $total_general += $subtotal;

                echo "<tr>
                        <td>{$detalle['t_p_descrip']}</td>
                        <td>{$detalle['p_descrip']}</td>
                        <td>{$detalle['u_descrip']}</td>
                        <td>" . number_format($precio, 0) . "</td>
                        <td>{$cantidad}</td>
                        <td>" . number_format($subtotal, 0) . "</td>
                      </tr>";
            }
            ?>
        </tbody>
    </table>

    <div class="total">
        TOTAL COMPRA: <?php echo number_format($total_general, 0); ?>
    </div>

</body>
</html>
