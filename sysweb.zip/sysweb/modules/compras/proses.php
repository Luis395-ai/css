<?php
session_start();
require_once "../../config/database.php";

ini_set('display_errors', 1);
error_reporting(E_ALL);

if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
    header("Location: ../../index.php?alert=3");
    exit;
}

if (isset($_GET['act'])) {

    if ($_GET['act'] == 'insert') {
        if (isset($_POST['cod_compra'], $_POST['cod_proveedor'], $_POST['cod_deposito'], $_POST['nro_factura'], $_POST['fecha'])) {

            $cod_compra    = trim($_POST['cod_compra']);
            $cod_proveedor = trim($_POST['cod_proveedor']);
            $cod_deposito  = trim($_POST['cod_deposito']);
            $nro_factura   = trim($_POST['nro_factura']);
            $fecha         = trim($_POST['fecha']);
            $hora          = date('H:i:s');
            $id_user       = $_SESSION['id_user'] ?? null;
            $total_compra  = isset($_POST['total_compra']) ? (float)$_POST['total_compra'] : 0;

            pg_query($conn, "BEGIN");

            try {
                $sql_compra = "INSERT INTO compra 
                    (cod_compra, cod_proveedor, cod_deposito, nro_factura, fecha, hora, total_compra, estado, id_user)
                    VALUES ($1,$2,$3,$4,$5,$6,$7,'ACTIVO',$8)";
                $res = pg_query_params($conn, $sql_compra, [
                    $cod_compra, $cod_proveedor, $cod_deposito, $nro_factura,
                    $fecha, $hora, $total_compra, $id_user
                ]);
                if (!$res) throw new Exception(pg_last_error($conn));

                if (isset($_POST['productos']) && count($_POST['productos']) > 0) {
                    $productos = $_POST['productos'];
                    $cantidades = $_POST['cantidades'];
                    $precios = $_POST['precios'];

                    for ($i=0; $i<count($productos); $i++) {
                        $cod_producto = $productos[$i];
                        $cantidad = (int)$cantidades[$i];
                        $precio = (float)$precios[$i];

                        $sql_detalle = "INSERT INTO detalle_compra (cod_compra, cod_producto, cod_deposito, precio, cantidad)
                                        VALUES ($1,$2,$3,$4,$5)";
                        $res_det = pg_query_params($conn, $sql_detalle, [
                            $cod_compra, $cod_producto, $cod_deposito, $precio, $cantidad
                        ]);
                        if (!$res_det) throw new Exception(pg_last_error($conn));

                        $sql_check = "SELECT cantidad FROM stock WHERE cod_producto=$1 AND cod_deposito=$2";
                        $res_check = pg_query_params($conn, $sql_check, [$cod_producto, $cod_deposito]);
                        $stock = pg_fetch_assoc($res_check);

                        if ($stock) {
                            $sql_upd = "UPDATE stock SET cantidad = cantidad + $1 WHERE cod_producto=$2 AND cod_deposito=$3";
                            $res_upd = pg_query_params($conn, $sql_upd, [$cantidad, $cod_producto, $cod_deposito]);
                            if (!$res_upd) throw new Exception(pg_last_error($conn));
                        } else {
                            $sql_ins = "INSERT INTO stock (cod_producto, cod_deposito, cantidad) VALUES ($1,$2,$3)";
                            $res_ins = pg_query_params($conn, $sql_ins, [$cod_producto, $cod_deposito, $cantidad]);
                            if (!$res_ins) throw new Exception(pg_last_error($conn));
                        }
                    }
                } else throw new Exception("Debe agregar productos");

                pg_query($conn, "COMMIT");
                header("Location: ../../mind.php?module=compras&alert=1");
                exit;

            } catch (Exception $e) {
                pg_query($conn, "ROLLBACK");
                echo "<h3>ERROR:</h3><p>".$e->getMessage()."</p>";
            }

        } else {
            header("Location: ../../mind.php?module=compras&alert=5");
            exit;
        }
    }

    if ($_GET['act'] == 'anular') {
        if (isset($_GET['id'])) {
            $cod_compra = (int)$_GET['id'];

            pg_query($conn, "BEGIN");
            try {
                $sql_update = "UPDATE compra SET estado='anulado' WHERE cod_compra=$1";
                $res = pg_query_params($conn, $sql_update, [$cod_compra]);
                if (!$res) throw new Exception(pg_last_error($conn));

                $sql_detalles = "SELECT cod_producto, cod_deposito, cantidad FROM detalle_compra WHERE cod_compra=$1";
                $res_detalles = pg_query_params($conn, $sql_detalles, [$cod_compra]);

                while ($row = pg_fetch_assoc($res_detalles)) {
                    $sql_stock = "UPDATE stock SET cantidad = cantidad - $1 
                                  WHERE cod_producto=$2 AND cod_deposito=$3";
                    $res_stock = pg_query_params($conn, $sql_stock, [$row['cantidad'], $row['cod_producto'], $row['cod_deposito']]);
                    if (!$res_stock) throw new Exception(pg_last_error($conn));
                }

                pg_query($conn, "COMMIT");
                header("Location: ../../mind.php?module=compras&alert=3");
                exit;

            } catch (Exception $e) {
                pg_query($conn, "ROLLBACK");
                echo "<h3>ERROR AL ANULAR:</h3><p>".$e->getMessage()."</p>";
            }
        } else {
            header("Location: ../../mind.php?module=compras&alert=5");
            exit;
        }
    }
}
?>
