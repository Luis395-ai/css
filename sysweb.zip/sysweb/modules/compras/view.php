<section class="content-header">
  <ol class="breadcrumb">
    <li><a href="?module=start" class="fa fa-home"><i></i>Inicio</a></li>
    <li class="active"><a href="?module=compras">Compras</a></li>
  </ol>
  <h1>
    <i class="fa fa-shopping-cart icon-title"></i> Registro de Compras   
    <a class="btn btn-primary btn-social pull-right" href="?module=form_compras&form=add" title="Agregar" data-toggle="tooltip">
      <i class="fa fa-plus"></i> Agregar
    </a>
  </h1>
</section>

<section class="content">
  <div class="row">
    <div class="col-md-12">
      <?php
        if (!empty($_GET['alert'])) {
          switch ($_GET['alert']) {
            case 1:
              echo "<div class='alert alert-success alert-dismissable'>
                      <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                      <h4><i class='icon fa fa-check-circle'></i> Exitoso!</h4>
                      Compra registrada correctamente
                    </div>";
              break;
            case 2:
              echo "<div class='alert alert-success alert-dismissable'>
                      <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                      <h4><i class='icon fa fa-check-circle'></i> Exitoso!</h4>
                      Compra modificada correctamente
                    </div>";
              break;
            case 3:
              echo "<div class='alert alert-success alert-dismissable'>
                      <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                      <h4><i class='icon fa fa-check-circle'></i> Exitoso!</h4>
                      Compra anulada correctamente
                    </div>";
              break;
            case 4:
              echo "<div class='alert alert-danger alert-dismissable'>
                      <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                      <h4><i class='icon fa fa-times-circle'></i> Error!</h4>
                      No se pudo realizar la operación correctamente
                    </div>";
              break;
            case 5:
              echo "<div class='alert alert-warning alert-dismissable'>
                      <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                      <h4><i class='icon fa fa-exclamation-triangle'></i> Atención!</h4>
                      Los campos no pueden estar vacíos
                    </div>";
              break;
          }
        }
      ?>

      <div class="box box-primary">
        <div class="box-body">
          <h2>Lista de Compras</h2>

          <div class="form-inline" style="margin-bottom:10px;">
            <label for="registros">Mostrar </label>
            <select id="registros" class="form-control input-sm">
              <option value="5">5</option>
              <option value="10" selected>10</option>
              <option value="25">25</option>
              <option value="50">50</option>
              <option value="100">100</option>
            </select>
            <label> registros</label>

            <div class="pull-right">
              <label for="buscar">Buscar: </label>
              <input type="text" id="buscar" class="form-control input-sm" placeholder="Escribe para buscar...">
            </div>
          </div>

          <table id="dataTables1" class="table table-bordered table-striped table-hover">
            <thead>
              <tr>
                <th class="center">Código Compra</th>
                <th class="center">Proveedor</th>
                <th class="center">Depósito</th>
                <th class="center">N° Factura</th>
                <th class="center">Fecha</th>
                <th class="center">Hora</th>
                <th class="center">Acción</th>
              </tr>
            </thead>
          <tbody>
<?php
$query = pg_query($conn, "SELECT c.cod_compra, p.razon_social, d.descrip, c.nro_factura, c.fecha, c.hora, c.estado
                          FROM compra c
                          JOIN proveedor p ON c.cod_proveedor = p.cod_proveedor
                          JOIN deposito d ON c.cod_deposito = d.cod_deposito
                          ORDER BY c.cod_compra DESC")
    or die("Error: ".pg_last_error($conn));

while ($data = pg_fetch_assoc($query)) {
    $cod_compra   = $data['cod_compra'];
    $razon_social = $data['razon_social'];
    $descrip      = $data['descrip'];
    $nro_factura  = $data['nro_factura'];
    $fecha        = $data['fecha'];
    $hora         = $data['hora'];
    $estado       = $data['estado'];

    $fila_class = ($estado == 'anulado') ? "style='background-color:#f2dede; color:#a94442;'" : "";

    echo "<tr $fila_class>
            <td class='center'>$cod_compra</td>
            <td class='center'>$razon_social</td>
            <td class='center'>$descrip</td>
            <td class='center'>$nro_factura</td>
            <td class='center'>$fecha</td>
            <td class='center'>$hora</td>
            <td class='center' width='150'>";
    
    if ($estado == 'activo') {
        echo "<div>
                <a data-toggle='tooltip' data-placement='top' title='Imprimir' style='margin-right:5px'
                   class='btn btn-success btn-sm' href='modules/compras/print.php?id=$cod_compra' target='_blank'>
                   <i class='fa fa-print'></i>
                </a>
                <a data-toggle='tooltip' data-placement='top' title='Anular' class='btn btn-danger btn-sm'
                   href='modules/compras/proses.php?act=anular&id=$cod_compra'
                   onclick='return confirm(\"¿Estás seguro/a de anular la compra N° $cod_compra?\");'>
                   <i class='glyphicon glyphicon-remove'></i>
                </a>
              </div>";
    } else {
        echo "<span class='label label-danger'>ANULADO</span>";
    }

    echo "</td></tr>";
}
?>
</tbody>

          </table>
        </div>
      </div>
    </div>
  </div>
</section>
