<?php
// --- FORMULARIO PARA AGREGAR ---
if (isset($_GET['form']) && $_GET['form'] === 'add') { 
  $query_id = pg_query($conn, "SELECT MAX(id_departamento) as id FROM departamento")
              or die('Error: '.pg_last_error($conn));
  $data_id = pg_fetch_assoc($query_id);
  $codigo = ($data_id && $data_id['id'] != null) ? $data_id['id'] + 1 : 1;
?>
  <section class="content-header">
    <h1><i class="fa fa-edit icon-title"></i> Agregar departamento</h1>
    <ol class="breadcrumb">
      <li><a href="?module=start"><i class="fa fa-home"></i> Inicio</a></li>
      <li><a href="?module=departamento">Departamento</a></li>
      <li class="active">Agregar</li>
    </ol>
  </section>

  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <form role="form" class="form-horizontal" 
                action="modules/departamento/proses.php?act=insert" 
                method="POST">
            <div class="box-body">
              <div class="form-group">
                <label class="col-sm-2 control-label">Código</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" 
                         name="codigo" 
                         value="<?php echo htmlspecialchars($codigo); ?>" readonly>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Descripción</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" 
                         name="dep_descripcion" 
                         placeholder="Ingresa un departamento" required>
                </div>
              </div>
            </div>
            <div class="box-footer">
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                  <input type="submit" class="btn btn-primary btn-submit" value="Guardar">
                  <a href="?module=departamento" class="btn btn-default btn-reset">Cancelar</a>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>

<?php 
// --- FORMULARIO PARA EDITAR ---
} elseif (isset($_GET['form']) && $_GET['form'] === 'edit') { 
  $id_departamento = "";
  $dep_descripcion = "";

  if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = (int) $_GET['id'];
    $query = pg_query($conn, "SELECT * FROM departamento WHERE id_departamento = $id")
             or die('Error: '.pg_last_error($conn));
    if ($data = pg_fetch_assoc($query)) {
      $id_departamento = $data['id_departamento'];
      $dep_descripcion = $data['dep_descripcion'];
    }
  }
?>
  <section class="content-header">
    <h1><i class="fa fa-edit icon-title"></i> Modificar departamento</h1>
    <ol class="breadcrumb">
      <li><a href="?module=start"><i class="fa fa-home"></i> Inicio</a></li>
      <li><a href="?module=departamento">Departamento</a></li>
      <li class="active">Modificar</li>
    </ol>
  </section>

  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <form role="form" class="form-horizontal" 
                action="modules/departamento/proses.php?act=update" 
                method="POST">
            <div class="box-body">
              <div class="form-group">
                <label class="col-sm-2 control-label">Código</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" 
                         name="id_departamento" 
                         value="<?php echo htmlspecialchars($id_departamento); ?>" readonly>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Descripción</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" 
                         name="dep_descripcion" required 
                         value="<?php echo htmlspecialchars($dep_descripcion); ?>">
                </div>
              </div>
            </div>
            <div class="box-footer">
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                  <input type="submit" class="btn btn-primary btn-submit" value="Guardar">
                  <a href="?module=departamento" class="btn btn-default btn-reset">Cancelar</a>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
<?php 
} 
?>
