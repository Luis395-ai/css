<?php
require_once "../../config/database.php";
$query = pg_query($conn, "SELECT * FROM departamento ORDER BY id_departamento ASC")
    or die("Error: ".pg_last_error($conn));
$count = pg_num_rows($query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Departamentos</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #333;
            padding: 8px;
            text-align: left;
        }
        th {
            background: #f2f2f2;
        }
        th.codigo, td.codigo {
            width: 20%;
        }
        th.descripcion, td.descripcion {
            width: 80%;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .cabecera-img {
            display: block;
            margin: 0 auto 20px auto;
            max-width: 120px;
        }
    </style>
</head>
<body>
    <img src="../../assets/img/log.png" alt="Icono" class="cabecera-img">
    <h2>Lista de Departamentos</h2>
    <table>
        <thead>
            <tr>
                <th class="codigo">Código</th>
                <th class="descripcion">Descripción</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($data = pg_fetch_assoc($query)) {
                echo "<tr>
                        <td class='codigo'>{$data['id_departamento']}</td>
                        <td class='descripcion'>{$data['dep_descripcion']}</td>
                      </tr>";
            }
            ?>
        </tbody>
    </table>
    <p>Total de departamentos: <?php echo $count; ?></p>
</body>
</html>