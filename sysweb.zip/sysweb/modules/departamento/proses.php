<?php
session_start();
require_once "../../config/database.php";

// Mostrar errores (solo para depuración)
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
    header("Location: ../../index.php?alert=3");
    exit;
} else {
    // --- Isertar ---
    if (isset($_GET['act']) && $_GET['act'] == 'insert') {
        if (isset($_POST['codigo'], $_POST['dep_descripcion'])) {
            $codigo          = trim($_POST['codigo']);
            $dep_descripcion = trim($_POST['dep_descripcion']);

            if ($codigo !== "" && $dep_descripcion !== "") {
                $sql = "INSERT INTO departamento (id_departamento, dep_descripcion) VALUES ($1, $2)";
                $result = pg_query_params($conn, $sql, array($codigo, $dep_descripcion));

                if ($result) {
                    header("Location: ../../mind.php?module=departamento&alert=1");
                    exit;
                } else {
                    header("Location: ../../mind.php?module=departamento&alert=4");
                    exit;
                }
            } else {
                header("Location: ../../mind.php?module=departamento&alert=5");
                exit;
            }
        }
    }

    // --- Actualizar ---
    elseif (isset($_GET['act']) && $_GET['act'] == 'update') {
        if (isset($_POST['id_departamento'], $_POST['dep_descripcion'])) {
            $id   = trim($_POST['id_departamento']);
            $desc = trim($_POST['dep_descripcion']);

            if ($id !== "" && $desc !== "") {
                $sql = "UPDATE departamento SET dep_descripcion = $1 WHERE id_departamento = $2";
                $result = pg_query_params($conn, $sql, array($desc, $id));

                if ($result) {
                    header("Location: ../../mind.php?module=departamento&alert=2");
                    exit;
                } else {
                    header("Location: ../../mind.php?module=departamento&alert=4");
                    exit;
                }
            } else {
                header("Location: ../../mind.php?module=departamento&alert=5");
                exit;
            }
        }
    }

    // --- Eliminar ---
    elseif (isset($_GET['act']) && $_GET['act'] == 'delete') {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];

            $sql = "DELETE FROM departamento WHERE id_departamento = $1";
            $result = pg_query_params($conn, $sql, array($id));

            if ($result) {
                header("Location: ../../mind.php?module=departamento&alert=3");
                exit;
            } else {
                header("Location: ../../mind.php?module=departamento&alert=4");
                exit;
            }
        }
    }
}
