<?php
session_start();
require_once "../../config/database.php";

ini_set('display_errors', 1);
error_reporting(E_ALL);

if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
    header("Location: ../../index.php?alert=3");
    exit;
} else {
    // --- Insertar ---
    if (isset($_GET['act']) && $_GET['act'] == 'insert') {
        if (isset($_POST['codigo'], $_POST['descrip'])) {
            $codigo    = trim($_POST['codigo']);
            $descrip = trim($_POST['descrip']);

            if ($codigo !== "" && $descrip !== "") {
                $sql = "INSERT INTO deposito (cod_deposito, descrip) VALUES ($1, $2)";
                $result = pg_query_params($conn, $sql, array($codigo, $descrip));

                if ($result) {
                    header("Location: ../../mind.php?module=deposito&alert=1");
                    exit;
                } else {
                    header("Location: ../../mind.php?module=deposito&alert=4");
                    exit;
                }
            } else {
                header("Location: ../../mind.php?module=deposito&alert=5");
                exit;
            }
        }
    }
    elseif (isset($_GET['act']) && $_GET['act'] == 'update') {
        if (isset($_POST['cod_deposito'], $_POST['descrip'])) {
            $id   = trim($_POST['cod_deposito']);
            $desc = trim($_POST['descrip']);

            if ($id !== "" && $desc !== "") {
                $sql = "UPDATE deposito SET descrip = $1 WHERE cod_deposito = $2";
                $result = pg_query_params($conn, $sql, array($desc, $id));

                if ($result) {
                    header("Location: ../../mind.php?module=deposito&alert=2");
                    exit;
                } else {
                    header("Location: ../../mind.php?module=deposito&alert=4");
                    exit;
                }
            } else {
                header("Location: ../../mind.php?module=deposito&alert=5");
                exit;
            }
        }
    }
    elseif (isset($_GET['act']) && $_GET['act'] == 'delete') {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];

            $sql = "DELETE FROM deposito WHERE cod_deposito = $1";
            $result = pg_query_params($conn, $sql, array($id));

            if ($result) {
                header("Location: ../../mind.php?module=deposito&alert=3");
                exit;
            } else {
                header("Location: ../../mind.php?module=deposito&alert=4");
                exit;
            }
        }
    }
}
?>