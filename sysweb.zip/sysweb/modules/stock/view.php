<section class="content-header">
  <ol class="breadcrumb">
    <li><a href="?module=start" class="fa fa-home"><i></i>Inicio</a></li>
    <li class="active"><a href="?module=stock">Stock</a></li>
  </ol>
  <h1>
    <i class="fa fa-shopping-cart icon-title"></i> Registro de stock 
  </h1>
</section>

<section class="content">
  <div class="row">
    <div class="col-md-12">
      <?php
      if(isset($_POST['cod_deposito']) && !empty($_POST['cod_deposito'])) {
          $cod_deposito = $_POST['cod_deposito'];
      } else {
          $cod_deposito = 1; 
      }
      ?>
      
      <div class="box box-primary">
        <div class="box-header">
          <form role="form" class="form-horizontal" method="POST">
            <div class="form-group">
              <label class="col-sm-2 control-label">Depósito</label>
              <div class="col-sm-4">
                <select name="cod_deposito" class="form-control" required>
                  <option value="">- Seleccionar Depósito -</option>
                  <?php
                  $query_dep = pg_query($conn, "SELECT * FROM deposito ORDER BY cod_deposito");
                  while($dep = pg_fetch_assoc($query_dep)){
                      $selected = ($dep['cod_deposito'] == $cod_deposito) ? 'selected' : '';
                      echo "<option value='{$dep['cod_deposito']}' $selected>{$dep['descrip']}</option>";
                  }
                  ?>
                </select>
              </div>
              <div class="col-sm-3">
                <button type="submit" class="btn btn-primary btn-social btn-submit" style="width: 180px;">
                  <i class="fa fa-search icon-title"></i> Buscar depósito
                </button>
              </div>
            </div>
          </form>
        </div>
        
        <div class="box-body">
          <h2>Lista de stock</h2>

          <div class="form-group">
            <label> registros</label>

            <div class="pull-right">
              <label for="buscar">Buscar: </label>
              <input type="text" id="buscar" class="form-control input-sm" placeholder="Escribe para buscar...">
            </div>
          </div>

          <table id="dataTables1" class="table table-bordered table-striped table-hover">
            <thead>
              <tr>
                <th class="center">Depósito</th>
                <th class="center">Tip. producto</th>
                <th class="center">Producto</th>
                <th class="center">Unid. de medida</th>
                <th class="center">Cantidad</th>
              </tr>
            </thead>
            <tbody>
<?php
$query = pg_query($conn, "SELECT 
    pro.cod_producto, 
    pro.p_descrip, 
    dep.cod_deposito, 
    dep.descrip, 
    tpro.t_p_descrip, 
    um.u_descrip, 
    st.cantidad
FROM stock st
JOIN producto pro ON st.cod_producto = pro.cod_producto
JOIN deposito dep ON st.cod_deposito = dep.cod_deposito
JOIN tipo_producto tpro ON pro.cod_tipo_prod = tpro.cod_tipo_prod
JOIN u_medida um ON pro.id_u_medida = um.id_u_medida 
WHERE st.cod_deposito = $cod_deposito")
    or die("Error: ".pg_last_error($conn));

if (pg_num_rows($query) > 0) {
    while ($data = pg_fetch_assoc($query)) {
        $cod_producto = $data['cod_producto'];
        $p_descrip    = $data['p_descrip'];
        $cod_deposito = $data['cod_deposito'];
        $dep_descrip  = $data['descrip'];
        $t_p_descrip  = $data['t_p_descrip'];
        $u_descrip    = $data['u_descrip'];
        $cantidad     = $data['cantidad'];

        echo "<tr>
                <td class='center'>$dep_descrip</td>
                <td class='center'>$t_p_descrip</td>
                <td class='center'>$p_descrip</td>
                <td class='center'>$u_descrip</td>
                <td class='center'>$cantidad</td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='5' class='center'>No hay stock disponible para este depósito</td></tr>";
}
?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</section>