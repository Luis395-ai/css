<?php
require_once "../../config/database.php";
$query = pg_query($conn, "
    SELECT 
        cod_tipo_prod,
        t_p_descrip
    FROM tipo_producto
    ORDER BY cod_tipo_prod ASC
") or die("Error: ".pg_last_error($conn));
$count = pg_num_rows($query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reporte de Tipos de Producto</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            font-size: 11px;
        }
        th, td {
            border: 1px solid #333;
            padding: 5px;
            text-align: center;
        }
        th {
            background: #f2f2f2;
            font-weight: bold;
        }
        th.codigo, td.codigo {
            width: 20%;
        }
        th.descripcion, td.descripcion {
            width: 80%;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .cabecera-img {
            display: block;
            margin: 0 auto 20px auto;
            max-width: 120px;
        }
        .total {
            font-weight: bold;
            text-align: center;
            margin-top: 10px;
        }
        /* Para texto largo que pueda desbordar */
        td {
            word-wrap: break-word;
            max-width: 0;
            overflow: hidden;
        }
    </style>
</head>
<body>
    <img src="../../assets/img/log.png" alt="Icono" class="cabecera-img">
    <h2>Reporte de Tipos de Producto</h2>
    <table>
        <thead>
            <tr>
                <th class="codigo">Código</th>
                <th class="descripcion">Descripción</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($data = pg_fetch_assoc($query)) {
                echo "<tr>
                        <td class='codigo'>{$data['cod_tipo_prod']}</td>
                        <td class='descripcion'>{$data['t_p_descrip']}</td>
                      </tr>";
            }
            ?>
        </tbody>
    </table>
    <p class="total">Total de tipos de producto: <?php echo $count; ?></p>
</body>
</html>