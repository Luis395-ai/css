<?php
session_start();
require_once "../../config/database.php";

// Mostrar errores (solo para depuración)
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
    header("Location: ../../index.php?alert=3");
    exit;
} else {
    if (isset($_GET['act']) && $_GET['act'] == 'insert') {
        if (isset($_POST['codigo'], $_POST['t_p_descrip'])) {
            $codigo    = trim($_POST['codigo']);
            $t_p_descrip = trim($_POST['t_p_descrip']);

            if ($codigo !== "" && $t_p_descrip !== "") {
                $sql = "INSERT INTO tipo_producto (cod_tipo_prod, t_p_descrip) VALUES ($1, $2)";
                $result = pg_query_params($conn, $sql, array($codigo, $t_p_descrip));

                if ($result) {
                    header("Location: ../../mind.php?module=tipo_producto&alert=1");
                    exit;
                } else {
                    header("Location: ../../mind.php?module=tipo_producto&alert=4");
                    exit;
                }
            } else {
                header("Location: ../../mind.php?module=tipo_producto&alert=5");
                exit;
            }
        }
    }
    elseif (isset($_GET['act']) && $_GET['act'] == 'update') {
        if (isset($_POST['cod_tipo_prod'], $_POST['t_p_descrip'])) {
            $id   = trim($_POST['cod_tipo_prod']);
            $desc = trim($_POST['t_p_descrip']);

            if ($id !== "" && $desc !== "") {
                $sql = "UPDATE tipo_producto SET t_p_descrip = $1 WHERE cod_tipo_prod = $2";
                $result = pg_query_params($conn, $sql, array($desc, $id));

                if ($result) {
                    header("Location: ../../mind.php?module=tipo_producto&alert=2");
                    exit;
                } else {
                    header("Location: ../../mind.php?module=tipo_producto&alert=4");
                    exit;
                }
            } else {
                header("Location: ../../mind.php?module=tipo_producto&alert=5");
                exit;
            }
        }
    }
    elseif (isset($_GET['act']) && $_GET['act'] == 'delete') {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];

            $sql = "DELETE FROM tipo_producto WHERE cod_tipo_prod = $1";
            $result = pg_query_params($conn, $sql, array($id));

            if ($result) {
                header("Location: ../../mind.php?module=tipo_producto&alert=3");
                exit;
            } else {
                header("Location: ../../mind.php?module=tipo_producto&alert=4");
                exit;
            }
        }
    }
}
?>