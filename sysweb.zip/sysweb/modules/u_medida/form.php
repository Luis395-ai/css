<?php
if (isset($_GET['form']) && $_GET['form'] === 'add') { 
  $query_id = pg_query($conn, "SELECT MAX(id_u_medida) as id FROM u_medida")
              or die('Error: '.pg_last_error($conn));
  $data_id = pg_fetch_assoc($query_id);
  $codigo = ($data_id && $data_id['id'] != null) ? $data_id['id'] + 1 : 1;
?>
  <section class="content-header">
    <h1><i class="fa fa-edit icon-title"></i> Agregar Unidad de Medida</h1>
    <ol class="breadcrumb">
      <li><a href="?module=start"><i class="fa fa-home"></i> Inicio</a></li>
      <li><a href="?module=u_medida">Unidad de Medida</a></li>
      <li class="active">Agregar</li>
    </ol>
  </section>

  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <form role="form" class="form-horizontal" 
                action="modules/u_medida/proces.php?act=insert" 
                method="POST">
            <div class="box-body">
              <div class="form-group">
                <label class="col-sm-2 control-label">Código</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" 
                         name="codigo" 
                         value="<?php echo htmlspecialchars($codigo); ?>" readonly>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Descripción</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" 
                         name="u_descrip" 
                         placeholder="Ingresa una unidad de medida" required>
                </div>
              </div>
            </div>
            <div class="box-footer">
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                  <input type="submit" class="btn btn-primary btn-submit" value="Guardar">
                  <a href="?module=u_medida" class="btn btn-default btn-reset">Cancelar</a>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>

<?php 
} elseif (isset($_GET['form']) && $_GET['form'] === 'edit') { 
  $id_u_medida = "";
  $u_descrip = "";

  if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = (int) $_GET['id'];
    $query = pg_query($conn, "SELECT * FROM u_medida WHERE id_u_medida = $id")
             or die('Error: '.pg_last_error($conn));
    if ($data = pg_fetch_assoc($query)) {
      $id_u_medida = $data['id_u_medida'];
      $u_descrip = $data['u_descrip'];
    }
  }
?>
  <section class="content-header">
    <h1><i class="fa fa-edit icon-title"></i> Modificar Unidad de Medida</h1>
    <ol class="breadcrumb">
      <li><a href="?module=start"><i class="fa fa-home"></i> Inicio</a></li>
      <li><a href="?module=u_medida">Unidad de Medida</a></li>
      <li class="active">Modificar</li>
    </ol>
  </section>

  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <form role="form" class="form-horizontal" 
                action="modules/u_medida/proces.php?act=update" 
                method="POST">
            <div class="box-body">
              <div class="form-group">
                <label class="col-sm-2 control-label">Código</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" 
                         name="id_u_medida" 
                         value="<?php echo htmlspecialchars($id_u_medida); ?>" readonly>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Descripción</label>
                <div class="col-sm-5">
                  <input type="text" class="form-control" 
                         name="u_descrip" required 
                         value="<?php echo htmlspecialchars($u_descrip); ?>">
                </div>
              </div>
            </div>
            <div class="box-footer">
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                  <input type="submit" class="btn btn-primary btn-submit" value="Guardar">
                  <a href="?module=u_medida" class="btn btn-default btn-reset">Cancelar</a>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
<?php 
} 
?>