<?php
session_start();
require_once "../../config/database.php";

// Mostrar errores (solo para depuración)
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
    header("Location: ../../index.php?alert=3");
    exit;
} else {
    // --- Insertar ---
    if (isset($_GET['act']) && $_GET['act'] == 'insert') {
        if (isset($_POST['codigo'], $_POST['u_descrip'])) {
            $codigo    = trim($_POST['codigo']);
            $u_descrip = trim($_POST['u_descrip']);

            if ($codigo !== "" && $u_descrip !== "") {
                $sql = "INSERT INTO u_medida (id_u_medida, u_descrip) VALUES ($1, $2)";
                $result = pg_query_params($conn, $sql, array($codigo, $u_descrip));

                if ($result) {
                    header("Location: ../../mind.php?module=u_medida&alert=1");
                    exit;
                } else {
                    header("Location: ../../mind.php?module=u_medida&alert=4");
                    exit;
                }
            } else {
                header("Location: ../../mind.php?module=u_medida&alert=5");
                exit;
            }
        }
    }

    // --- Actualizar ---
    elseif (isset($_GET['act']) && $_GET['act'] == 'update') {
        if (isset($_POST['id_u_medida'], $_POST['u_descrip'])) {
            $id   = trim($_POST['id_u_medida']);
            $desc = trim($_POST['u_descrip']);

            if ($id !== "" && $desc !== "") {
                $sql = "UPDATE u_medida SET u_descrip = $1 WHERE id_u_medida = $2";
                $result = pg_query_params($conn, $sql, array($desc, $id));

                if ($result) {
                    header("Location: ../../mind.php?module=u_medida&alert=2");
                    exit;
                } else {
                    header("Location: ../../mind.php?module=u_medida&alert=4");
                    exit;
                }
            } else {
                header("Location: ../../mind.php?module=u_medida&alert=5");
                exit;
            }
        }
    }

    // --- Eliminar ---
    elseif (isset($_GET['act']) && $_GET['act'] == 'delete') {
        if (isset($_GET['id'])) {
            $id = (int) $_GET['id'];

            $sql = "DELETE FROM u_medida WHERE id_u_medida = $1";
            $result = pg_query_params($conn, $sql, array($id));

            if ($result) {
                header("Location: ../../mind.php?module=u_medida&alert=3");
                exit;
            } else {
                header("Location: ../../mind.php?module=u_medida&alert=4");
                exit;
            }
        }
    }
}
?>