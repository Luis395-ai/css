
<!--este archivo lo que hace es que 
valida el token otra vez, actualiza la contraseña en la tabla usuarios y borra el token usado-->
<?php
session_start();
//verificar el archivo de configuracion
$database_path = $_SERVER['DOCUMENT_ROOT'] . '/sysweb/config/database.php';
if (!file_exists($database_path)) {
    die("Error: Archivo de configuracion no encontrado");
}

include($database_path);

if (!$conn) {
    die("Error: No se pudo conectar a la base de datos");
}
//para tener los datos enviados con token (codigo unico de recuperacion)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['token'])) {
    $token = $_POST['token'];
    $nueva_password = $_POST['nueva_password'];
    $confirmar_password = $_POST['confirmar_password'];
    //para verificar si ambas contraseñas coincinen
    if ($nueva_password !== $confirmar_password) {
        header('Location: reset_password.php?token=' . $token . '&alert=2');
        exit();
    }
    //buscar en la tabla el registro con ese token y el expires para
    //  que el enlace no haya expirado y el $1 para evitar inyeccion sql
    $query = "SELECT email FROM recuperar_contraseña WHERE token = $1 AND expires_at > NOW()";
    $result = pg_query_params($conn, $query, array($token));
    $solicitud = pg_fetch_assoc($result);
    
    if ($solicitud) {
        $email = $solicitud['email'];
   
        $password_hash = md5($nueva_password);
        //para editar contraseña
        $query = "UPDATE usuarios SET password = $1 WHERE email = $2";
        $result = pg_query_params($conn, $query, array($password_hash, $email));
        
        if ($result) {
            $query = "DELETE FROM recuperar_contraseña WHERE token = $1";
            pg_query_params($conn, $query, array($token));
            
            header('Location: index.php?alert=5');
            exit();
        } else {
            die("Error al actualizar la contraseña: " . pg_last_error($conn));
        }
    } else {
        header('Location: reset_password.php?alert=3');
        exit();
    }
} else {
    header('Location: recuperar.php');
    exit();
}
?>