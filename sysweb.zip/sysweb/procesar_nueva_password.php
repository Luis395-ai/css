<?php
session_start();

// Incluir la configuración de la base de datos
include('database.php');

if (!$conn) {
    die("Error: No se pudo conectar a la base de datos");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['token'])) {
    $token = $_POST['token'];
    $nueva_password = $_POST['nueva_password'];
    $confirmar_password = $_POST['confirmar_password'];
    
    // Verificar que las contraseñas coincidan
    if ($nueva_password !== $confirmar_password) {
        header('Location: reset_password.php?token=' . $token . '&alert=2');
        exit();
    }
    
    // Verificar si el token es válido
    $query = "SELECT * FROM recuperar_contraseña WHERE token = $1 AND expires_at > NOW()";
    $result = pg_query_params($conn, $query, array($token));
    $solicitud = pg_fetch_assoc($result);
    
    if ($solicitud) {
        $email = $solicitud['email'];
        
        // Hashear la nueva contraseña
        $password_hash = password_hash($nueva_password, PASSWORD_DEFAULT);
        
        // Actualizar la contraseña en la tabla de usuarios
        // AJUSTA 'usuarios' y 'password' por tus nombres reales de tabla y campo
        $query = "UPDATE usuarios SET password = $1 WHERE email = $2";
        $result = pg_query_params($conn, $query, array($password_hash, $email));
        
        if ($result) {
            // Eliminar el token usado
            $query = "DELETE FROM recuperar_contraseña WHERE token = $1";
            pg_query_params($conn, $query, array($token));
            
            header('Location: index.php?alert=5');
            exit();
        } else {
            die("Error al actualizar la contraseña: " . pg_last_error($conn));
        }
    } else {
        header('Location: reset_password.php?alert=3');
        exit();
    }
} else {
    header('Location: recuperar.php');
    exit();
}
?>