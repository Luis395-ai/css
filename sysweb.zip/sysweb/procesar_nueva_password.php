<?php
session_start();

$database_path = $_SERVER['DOCUMENT_ROOT'] . '/sysweb/config/database.php';
if (!file_exists($database_path)) {
    die("Error: Archivo de configuracion no encontrado");
}

include($database_path);

if (!$conn) {
    die("Error: No se pudo conectar a la base de datos");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['token'])) {
    $token = $_POST['token'];
    $nueva_password = $_POST['nueva_password'];
    $confirmar_password = $_POST['confirmar_password'];
    
    if ($nueva_password !== $confirmar_password) {
        header('Location: reset_password.php?token=' . $token . '&alert=2');
        exit();
    }
    
    $query = "SELECT email FROM recuperar_contraseña WHERE token = $1 AND expires_at > NOW()";
    $result = pg_query_params($conn, $query, array($token));
    $solicitud = pg_fetch_assoc($result);
    
    if ($solicitud) {
        $email = $solicitud['email'];
   
        $password_hash = md5($nueva_password);
        
        $query = "UPDATE usuarios SET password = $1 WHERE email = $2";
        $result = pg_query_params($conn, $query, array($password_hash, $email));
        
        if ($result) {
            $query = "DELETE FROM recuperar_contraseña WHERE token = $1";
            pg_query_params($conn, $query, array($token));
            
            header('Location: index.php?alert=5');
            exit();
        } else {
            die("Error al actualizar la contraseña: " . pg_last_error($conn));
        }
    } else {
        header('Location: reset_password.php?alert=3');
        exit();
    }
} else {
    header('Location: recuperar.php');
    exit();
}
?>