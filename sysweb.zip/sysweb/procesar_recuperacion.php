<!-- archivo encargado de enviar el enclace -->
<?php
session_start();
require_once "config/database.php";
// se usa clases phpmailer para enviat corrreo desde php 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';

if (!$conn) {
    die("Error: No se pudo conectar a la base de datos");
}
//Verifica que se haya enviado el formulario por post y 
//limpia el campo de correo (email).
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['email'])) {
    $email = trim($_POST['email']);
    if (empty($email)) {
        header('Location: recuperar.php?alert=3');
        exit();
    }
//para verificar si el correo existe 
    $query = "SELECT id_user FROM usuarios WHERE email = $1";
    $result = pg_query_params($conn, $query, array($email));
 //si existe el correo se genera el token unico 
    if ($result && pg_num_rows($result) > 0) {
        $token = bin2hex(random_bytes(50));
        $expiracion = date('Y-m-d H:i:s', strtotime('+1 hour'));

        $query = "INSERT INTO recuperar_contraseña (email, token, expires_at) VALUES ($1, $2, $3)";
        $result = pg_query_params($conn, $query, array($email, $token, $expiracion));

        if ($result) {
            $enlace_recuperacion = "http://192.168.100.8/sysweb/reset_password.php?token=" . $token;
  //Este e password es la contraseña de aplicacion de Gmail, no la del correo normal.
//(google requiere ese tipo de contraseña para usar PHPMailer.)
//este es la cuenta de donde se va a enviar el enlace 
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'luiskake496@gmail.com';
                $mail->Password = 'rply nfnj chwx vckv';
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;

                $mail->setFrom('luiskake496@gmail.com', 'Luis Kake');
                $mail->addAddress($email);

                $mail->isHTML(true);
                $mail->Subject = 'Recupera tu contraseña';
                $mail->Body    = "Haz clic en el siguiente enlace para recuperar tu contraseña:<br><a href='$enlace_recuperacion'>$enlace_recuperacion</a>";

                $mail->send();
            } catch (Exception $e) {
            }

            header('Location: recuperar.php?alert=1');
            exit();
        } else {
            die("Error al guardar el token: " . pg_last_error($conn));
        }
    } else {
        header('Location: recuperar.php?alert=2');
        exit();
    }
} else {
    header('Location: recuperar.php');
    exit();
}
?>