<?php
session_start();

// Incluir la configuración de la base de datos
require_once "config/database.php";

// Incluir PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';

if (!$conn) {
    die("Error: No se pudo conectar a la base de datos");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['email'])) {
    $email = trim($_POST['email']);
    
    if (empty($email)) {
        header('Location: recuperar.php?alert=3');
        exit();
    }
    
    // Verificar si el email existe en tu base de datos de usuarios
    $query = "SELECT * FROM usuarios WHERE email = $1";
    $result = pg_query_params($conn, $query, array($email));
    
    if ($result && pg_num_rows($result) > 0) {
        // Generar token único
        $token = bin2hex(random_bytes(50));
        $expiracion = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        // Guardar la solicitud en la tabla recuperar_contraseña
        $query = "INSERT INTO recuperar_contraseña (email, token, expires_at) VALUES ($1, $2, $3)";
        $result = pg_query_params($conn, $query, array($email, $token, $expiracion));
        
        if ($result) {
            $enlace_recuperacion = "http://" . $_SERVER['HTTP_HOST'] . "/sysweb/reset.password.php?token=" . $token;

            // Enviar correo con PHPMailer
            $mail = new PHPMailer(true);
            try {
            
                       $mail->isSMTP();
                      $mail->Host = 'smtp.gmail.com';
                  $mail->SMTPAuth = true;
              $mail->Username = 'luiskake496@gmail.com';
                     $mail->Password = 'TU_CONTRASEÑA_DE_APLICACION'; // No tu contraseña normal
                    $mail->SMTPSecure = 'tls';
                    $mail->Port = 587;

$mail->setFrom('luiskake496@gmail.com', 'Luis Kake');
$mail->addAddress($email);

                $mail->isHTML(true);
                $mail->Subject = 'Recupera tu contraseña';
                $mail->Body    = "Haz clic en el siguiente enlace para recuperar tu contraseña:<br><a href='$enlace_recuperacion'>$enlace_recuperacion</a>";

                $mail->send();
                // Si quieres, puedes mostrar un mensaje de éxito aquí
            } catch (Exception $e) {
                // Puedes registrar el error o mostrar un mensaje
                // echo "No se pudo enviar el correo. Error: {$mail->ErrorInfo}";
            }

            $_SESSION['enlace_recuperacion'] = $enlace_recuperacion;
            $_SESSION['email_usuario'] = $email;
            
            header('Location: recuperar.php?alert=1');
            exit();
        } else {
            die("Error al guardar el token: " . pg_last_error($conn));
        }
        
    } else {
        header('Location: recuperar.php?alert=2');
        exit();
    }
} else {
    header('Location: recuperar.php');
    exit();
}
?>