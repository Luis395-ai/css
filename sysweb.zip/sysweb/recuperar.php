<!--este archivo es la parte visual o de interfaz que ve el usuario-->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="description" content="sysweb">
    <meta name="author" content="Luis">
    <title>Sysweb - Recuperar Contraseña</title>
<!-- estilos -->
    <link rel="shortcut icon" href="/sysweb/assets/img/favicon.ico" />
    <link href="/sysweb/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="/sysweb/assets/plugins/font-awesome-4.6.3/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
    <link href="/sysweb/assets/css/AdminLTE.min.css" rel="stylesheet" type="text/css"/>
    <link href="/sysweb/assets/css/style.css" rel="stylesheet" type="text/css"/>
</head>
<body class="hold-transition login-page">
    <div class="login-box">
        <div class="login-logo" style="color:antiquewhite;">
            <img src="/sysweb/assets/img/favicon.ico" alt="SysWeb" style="margin-top:15px; height:50px;">
            <br><b>Sysweb - Recuperar Contraseña</b>
        </div>

        <div class="login-box-body">
            <?php
            session_start();
            $alert = isset($_GET['alert']) ? (int) $_GET['alert'] : 0;
            if ($alert === 1) {
                echo '<div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Cerrar"><span aria-hidden="true">&times;</span></button>
                        <h4><i class="icon fa fa-check-circle"></i> Éxito!</h4>
                        Se ha enviado un enlace de recuperación a tu correo electrónico.
                      </div>';
            } elseif ($alert === 2) {
                echo '<div class="alert alert-danger alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Cerrar"><span aria-hidden="true">&times;</span></button>
                        <h4><i class="icon fa fa-times-circle"></i> Error!</h4>
                        El correo electrónico no existe en nuestro sistema.
                      </div>';
            } elseif ($alert === 3) {
                echo '<div class="alert alert-danger alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Cerrar"><span aria-hidden="true">&times;</span></button>
                        <h4><i class="icon fa fa-times-circle"></i> Error!</h4>
                        Por favor ingresa tu correo electrónico.
                      </div>';
            }
            ?>

            <p class="login-box-msg">
                <i class="fa fa-key icon-title"></i> Recuperar contraseña
            </p>

            <form action="procesar_recuperacion.php" method="post" autocomplete="off">
                <div class="form-group has-feedback">
                    <input type="email" class="form-control" name="email" placeholder="Correo electrónico" required>
                    <span class="glyphicon glyphicon-envelope form-control-feedback" aria-hidden="true"></span>
                </div>

                <div class="row">
                    <div class="col-xs-12">
                        <button type="submit" class="btn btn-primary btn-block btn-flat" name="recuperar">Enviar enlace de recuperación</button>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xs-12" style="margin-top: 15px; text-align: center;">
                        <a href="index.php">← Volver al login</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script src="/sysweb/assets/plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <script src="/sysweb/assets/js/bootstrap.min.js" type="text/javascript"></script>
</body>
</html>