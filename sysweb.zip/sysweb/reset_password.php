<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="description" content="sysweb">
    <meta name="author" content="Luis">
    <title>Sysweb - Nueva Contraseña</title>

    <link rel="shortcut icon" href="assets/img/favicon.ico" />
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="assets/plugins/font-awesome-4.6.3/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
    <link href="assets/css/AdminLTE.min.css" rel="stylesheet" type="text/css"/>
    <link href="assets/css/style.css" rel="stylesheet" type="text/css"/>
</head>
<body class="hold-transition login-page">
    <div class="login-box">
        <div class="login-logo" style="color:antiquewhite;">
            <img src="assets/img/favicon.ico" alt="SysWeb" style="margin-top:15px; height:50px;">
            <br><b>Sysweb - Nueva Contraseña</b>
        </div>

        <div class="login-box-body">
            <?php
            session_start();
            include('database.php');
            
            if (!$conn) {
                die("Error: No se pudo conectar a la base de datos");
            }
            
            $token = $_GET['token'] ?? '';
            $alert = isset($_GET['alert']) ? (int) $_GET['alert'] : 0;
            
            if ($alert === 1) {
                echo '<div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Cerrar"><span aria-hidden="true">&times;</span></button>
                        <h4><i class="icon fa fa-check-circle"></i> Éxito!</h4>
                        Contraseña actualizada correctamente.
                      </div>';
            } elseif ($alert === 2) {
                echo '<div class="alert alert-danger alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Cerrar"><span aria-hidden="true">&times;</span></button>
                        <h4><i class="icon fa fa-times-circle"></i> Error!</h4>
                        Las contraseñas no coinciden.
                      </div>';
            } elseif ($alert === 3) {
                echo '<div class="alert alert-danger alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Cerrar"><span aria-hidden="true">&times;</span></button>
                        <h4><i class="icon fa fa-times-circle"></i> Error!</h4>
                        Enlace inválido o expirado.
                      </div>';
            }
            
            // Verificar si el token es válido
            if ($token) {
                $query = "SELECT * FROM recuperar_contraseña WHERE token = $1 AND expires_at > NOW()";
                $result = pg_query_params($conn, $query, array($token));
                $solicitud = pg_fetch_assoc($result);
                
                if (!$solicitud) {
                    header('Location: reset_password.php?alert=3');
                    exit();
                }
            ?>
            
            <p class="login-box-msg">
                <i class="fa fa-lock icon-title"></i> Crear nueva contraseña
            </p>

            <form action="procesar_nueva_password.php" method="post" autocomplete="off">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                
                <div class="form-group has-feedback">
                    <input type="password" class="form-control" name="nueva_password" placeholder="Nueva contraseña" required>
                    <span class="glyphicon glyphicon-lock form-control-feedback" aria-hidden="true"></span>
                </div>
                
                <div class="form-group has-feedback">
                    <input type="password" class="form-control" name="confirmar_password" placeholder="Confirmar contraseña" required>
                    <span class="glyphicon glyphicon-lock form-control-feedback" aria-hidden="true"></span>
                </div>

                <div class="row">
                    <div class="col-xs-12">
                        <button type="submit" class="btn btn-primary btn-block btn-flat" name="cambiar">Cambiar contraseña</button>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xs-12" style="margin-top: 15px; text-align: center;">
                        <a href="index.php">← Volver al login</a>
                    </div>
                </div>
            </form>
            
            <?php } else { ?>
                <div class="alert alert-danger">
                    <h4><i class="icon fa fa-warning"></i> Error!</h4>
                    Enlace de recuperación inválido.
                </div>
                <div class="text-center">
                    <a href="recuperar.php" class="btn btn-primary">Solicitar nuevo enlace</a>
                </div>
            <?php } ?>
        </div>
    </div>

    <script src="assets/plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
</body>
</html>