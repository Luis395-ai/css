<?php
session_start();

$database_path = $_SERVER['DOCUMENT_ROOT'] . '/sysweb/config/database.php';
if (!file_exists($database_path)) {
    $database_path = '../config/database.php';
}

include($database_path);

if (!$conn) {
    die("Error de conexión");
}

$token = $_GET['token'] ?? '';
$token_valido = false;
$email_usuario = '';

if (!empty($token)) {
    $query = "SELECT email, expires_at FROM recuperar_contraseña WHERE token = $1 AND expires_at > NOW()";
    $result = pg_query_params($conn, $query, array($token));
    
    if ($result) {
        $solicitud = pg_fetch_assoc($result);
        if ($solicitud) {
            $token_valido = true;
            $email_usuario = $solicitud['email'];
        }
    }
}

$alert = isset($_GET['alert']) ? (int)$_GET['alert'] : 0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sysweb - Nueva Contraseña</title>
    <link rel="shortcut icon" href="/sysweb/assets/img/favicon.ico" />
    <link href="/sysweb/assets/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="hold-transition login-page">
    <div class="login-box">
        <div class="login-logo">
            <img src="/sysweb/assets/img/favicon.ico" alt="SysWeb" style="height:50px;">
            <br><b>Nueva Contraseña</b>
        </div>
        <div class="login-box-body">
            <?php if ($token_valido): ?>
                <form action="procesar_nueva_password.php" method="post">
                    <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                    <div class="form-group">
                        <input type="password" class="form-control" name="nueva_password" placeholder="Nueva contraseña" required>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" name="confirmar_password" placeholder="Confirmar contraseña" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Cambiar contraseña</button>
                </form>
            <?php else: ?>
                <div class="alert alert-danger">Enlace no válido</div>
                <a href="recuperar.php" class="btn btn-primary">Solicitar nuevo enlace</a>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>