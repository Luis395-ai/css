<?php
ob_start(); 
?>

<ul class="sidebar-menu">
    <li class="header">Menú</li>

    <?php 
    $active_home = (isset($_GET['module']) && $_GET['module'] == 'start') ? "active" : "";
    ?>
    <li class="<?php echo $active_home; ?>">
        <a href="?module=start">
            <i class="fa fa-home"></i> <span>Inicio</span>
        </a>
    </li>

    <li class="treeview">
        <a href="javascript:void(0)">
            <i class="fa fa-file-text"></i> <span>Referenciales generales</span>
            <i class="fa fa-angle-left pull-right"></i>
        </a>    
        <ul class="treeview-menu">
            <li><a href="?module=departamento"><i class="fa fa-circle-o"></i> Departamento</a></li>
            <li><a href="?module=ciudad"><i class="fa fa-circle-o"></i> Ciudad</a></li>
        </ul>
    </li>

    <li class="treeview">
        <a href="javascript:void(0)">
            <i class="fa fa-certificate"></i> <span>Referenciales de compra</span>
            <i class="fa fa-angle-left pull-right"></i>
        </a>    
        <ul class="treeview-menu">
            <li><a href="?module=deposito"><i class="fa fa-circle-o"></i> Deposito</a></li>
            <li><a href="?module=proveedor"><i class="fa fa-circle-o"></i> Proveedor</a></li>
            <li><a href="?module=producto"><i class="fa fa-circle-o"></i> Producto</a></li>
            <li><a href="?module=u_medida"><i class="fa fa-circle-o"></i> Unidad de medida</a></li>
             <li><a href="?module=tipo_producto"><i class="fa fa-circle-o"></i>Tipo de producto</a></li>
        </ul>
    </li>

    <?php if ($_SESSION['permisos_acceso'] != 'Compras'): ?>
    <li class="treeview">
        <a href="javascript:void(0)">
            <i class="fa fa-cc-paypal"></i> <span>Referenciales de venta</span>
            <i class="fa fa-angle-left pull-right"></i>
        </a>    
        <ul class="treeview-menu">
            <li><a href="?module=clientes"><i class="fa fa-circle-o"></i> Clientes</a></li>
        </ul>
    </li>
    <?php endif; ?>

    <?php if ($_SESSION['permisos_acceso'] != 'Compras'): ?>
    <li>
        <a href="?module=user"><i class="fa fa-user"></i> Administrar usuarios</a>
    </li>
    <?php endif; ?>

    <li>
        <a href="?module=password"><i class="fa fa-user"></i> Cambiar Contraseña</a>
    </li>
</ul>

<?php
ob_end_flush();
?>