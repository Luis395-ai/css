<?php
$conn = @pg_connect("host=localhost port=5433 dbname=sysweb user=postgres password=1");
if (!$conn) {
    die("No se pudo conectar a PostgreSQL");
} else {
    echo "Conexión exitosa!<br>";
}

$sql = "SELECT * FROM usuarios ORDER BY id_user DESC";
$res = pg_query($conn, $sql);

if (!$res) {
    die("Error en la consulta: " . pg_last_error($conn));
}

$count = pg_num_rows($res);
echo "Cantidad de registros encontrados: $count <br><br>";

while ($row = pg_fetch_assoc($res)) {
    echo "ID: " . $row['id_user'] . " | Usuario: " . $row['username'] . " | Nombre: " . $row['name_user'] . " | Permiso: " . $row['permisos_acceso'] . " | Estado: " . $row['status'] . "<br>";
}
?>
