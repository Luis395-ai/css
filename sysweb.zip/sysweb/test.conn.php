<?php
require_once 'config/database.php';

// Test usuario LUIS
$username = 'LUIS';
$password = 'kiki';

$query = "SELECT username, password FROM usuarios WHERE username = $1";
$result = pg_query_params($conn, $query, [$username]);

if ($result && $user = pg_fetch_assoc($result)) {
    echo "Usuario encontrado: " . $user['username'] . "<br>";
    echo "Password BD: " . $user['password'] . "<br>";
    echo "MD5 de 'kiki': " . md5('kiki') . "<br>";
    echo "Coinciden: " . (md5('kiki') === $user['password'] ? 'SÍ' : 'NO');
} else {
    echo "Usuario NO encontrado";
}
?>

<?php
require_once 'config/database.php';

$username = 'LUIS';
$query = "SELECT password FROM usuarios WHERE username = $1";
$result = pg_query_params($conn, $query, [$username]);

if ($result && $user = pg_fetch_assoc($result)) {
    echo "Hash MD5 en BD: " . $user['password'] . "<br>";
    
    // Probemos algunas contraseñas comunes
    $common_passwords = ['LUIS', 'Luis', 'luis', '123', '1234', 'password', 'admin', 'kaka', 'koko'];
    
    foreach ($common_passwords as $pass) {
        if (md5($pass) === $user['password']) {
            echo "¡CONTRASEÑA ENCONTRADA: " . $pass . "!";
            break;
        }
    }
}
?>

<?php
require_once 'config/database.php';

$username = 'LUIS';
$query = "SELECT password FROM usuarios WHERE username = $1";
$result = pg_query_params($conn, $query, [$username]);

if ($result && $user = pg_fetch_assoc($result)) {
    echo "Hash MD5 en BD: " . $user['password'] . "<br>";
    
    // Probemos contraseñas comunes
    $common_passwords = ['LUIS', 'Luis', 'luis', '123', '1234', 'password', 'admin', 'kiki', 'kaka', 'koko', 'contra', 'secret', 'qwerty'];
    
    foreach ($common_passwords as $pass) {
        if (md5($pass) === $user['password']) {
            echo "¡CONTRASEÑA ENCONTRADA: " . $pass . "!";
            break;
        }
    }
    
    // Si no se encuentra, mostramos que necesitamos resetear
    echo "<br>Si no aparece arriba, la contraseña es desconocida.";
}
?>


<?php
// Crear archivo test-email.php para probar
$to = "tu_email@gmail.com";
$subject = "Test Email";
$message = "Este es un email de prueba";
$headers = "From: test@sysweb.com";

if (mail($to, $subject, $message, $headers)) {
    echo "Email enviado correctamente";
} else {
    echo "Error al enviar email";
}
?>